import { type Specialize } from '../../../../../misc/__specialization/specialize.js';
import { type ZigbeeCommand } from '../../../command/zigbee-command.js';
import {
  ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES,
  type ZigbeeGeneralCommandSpecialization,
} from '../zigbee-general-command.js';

export interface ZigbeeDiscoverCommandsGeneratedCommandStaticProperties
  extends ZigbeeGeneralCommandSpecialization {
  readonly command: 0x13;
}

export type ZigbeeDiscoverCommandsGeneratedCommand = Specialize<
  ZigbeeCommand,
  ZigbeeDiscoverCommandsGeneratedCommandStaticProperties
>;

export const ZIGBEE_DISCOVER_COMMANDS_GENERATED_COMMAND: ZigbeeDiscoverCommandsGeneratedCommandStaticProperties =
  Object.freeze({
    ...ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES,
    command: 0x13,
  });
