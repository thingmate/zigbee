2.5.20 Discover Commands Generated Command
