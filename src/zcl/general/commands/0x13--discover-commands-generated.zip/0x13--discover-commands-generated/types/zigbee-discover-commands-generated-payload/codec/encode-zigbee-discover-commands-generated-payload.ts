import { type Encoder } from '@xstd/codec';
import { type ZigbeeDiscoverCommandsGeneratedPayload } from '../zigbee-discover-commands-generated-payload.js';

export function encodeZigbeeDiscoverCommandsGeneratedPayload(
  encoder: Encoder,
  { startCommandIdentifier, maximumCommandIdentifiers }: ZigbeeDiscoverCommandsGeneratedPayload,
): void {
  encoder.uint8(startCommandIdentifier).uint8(maximumCommandIdentifiers);
}
