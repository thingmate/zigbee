export interface ZigbeeDiscoverCommandsGeneratedPayload {
  readonly startCommandIdentifier: number; // u8
  readonly maximumCommandIdentifiers: number; // u8
}
