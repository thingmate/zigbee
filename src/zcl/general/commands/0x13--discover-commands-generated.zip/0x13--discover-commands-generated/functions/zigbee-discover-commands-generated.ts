import { type Abortable, abortableContext } from '@xstd/abortable';
import { Decoder, Encoder } from '@xstd/codec';
import { isSpecialisationOf } from '../../../../../../misc/__specialization/is-specialisation-of.js';
import { type ZigbeeResource } from '../../../../__resource/zigbee-resource.js';
import { type ZigbeeCommand } from '../../../../command/zigbee-command.js';
import { decodeZigbeeDiscoverCommandsGeneratedResponsePayload } from '../../0x14--discover-commands-generated-response/types/zigbee-discover-commands-generated-response-payload/codec/decode-zigbee-discover-commands-generated-response-payload.js';
import { type ZigbeeDiscoverCommandsGeneratedResponsePayload } from '../../0x14--discover-commands-generated-response/types/zigbee-discover-commands-generated-response-payload/zigbee-discover-commands-generated-response-payload.js';
import { ZIGBEE_DISCOVER_COMMANDS_GENERATED_RESPONSE_COMMAND } from '../../0x14--discover-commands-generated-response/zigbee-discover-commands-generated-response-command.js';

import { encodeZigbeeDiscoverCommandsGeneratedPayload } from '../types/zigbee-discover-commands-generated-payload/codec/encode-zigbee-discover-commands-generated-payload.js';
import { type ZigbeeDiscoverCommandsGeneratedPayload } from '../types/zigbee-discover-commands-generated-payload/zigbee-discover-commands-generated-payload.js';
import { ZIGBEE_DISCOVER_COMMANDS_GENERATED_COMMAND } from '../zigbee-discover-commands-generated-command.js';

export interface ZigbeeDiscoverCommandsOptions
  extends Omit<ZigbeeCommand, 'clusterSpecific' | 'direction' | 'command' | 'payload'>,
    ZigbeeDiscoverCommandsGeneratedPayload,
    Abortable {
  readonly adapter: ZigbeeResource;
}

export function zigbeeDiscoverCommandsGenerated({
  adapter,
  startCommandIdentifier,
  maximumCommandIdentifiers,
  signal,
  ...requestCommand
}: ZigbeeDiscoverCommandsOptions): Promise<ZigbeeDiscoverCommandsGeneratedResponsePayload> {
  return abortableContext(
    async (signal: AbortSignal): Promise<ZigbeeDiscoverCommandsGeneratedResponsePayload> => {
      return (
        await Promise.all([
          adapter.receiver
            .mapFilter(
              (
                responseCommand: ZigbeeCommand,
              ): ZigbeeDiscoverCommandsGeneratedResponsePayload | null => {
                return (
                    isSpecialisationOf(responseCommand, {
                      ...requestCommand,
                      ...ZIGBEE_DISCOVER_COMMANDS_GENERATED_RESPONSE_COMMAND,
                      direction: 'server-to-client',
                    })
                  ) ?
                    Decoder.decode(
                      responseCommand.payload,
                      decodeZigbeeDiscoverCommandsGeneratedResponsePayload,
                    )
                  : null;
              },
            )
            .first({ signal }),
          adapter.send({
            ...requestCommand,
            ...ZIGBEE_DISCOVER_COMMANDS_GENERATED_COMMAND,
            clusterSpecific: false,
            direction: 'client-to-server',
            payload: Encoder.encode(
              { startCommandIdentifier, maximumCommandIdentifiers },
              encodeZigbeeDiscoverCommandsGeneratedPayload,
            ),
            signal,
          }),
        ])
      )[0];
    },
    { signal },
  );
}
