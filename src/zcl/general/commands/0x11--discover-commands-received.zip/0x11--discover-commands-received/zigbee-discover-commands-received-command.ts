import { type Specialize } from '../../../../../misc/__specialization/specialize.js';
import { type ZigbeeCommand } from '../../../command/zigbee-command.js';
import {
  ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES,
  type ZigbeeGeneralCommandSpecialization,
} from '../zigbee-general-command.js';

export interface ZigbeeDiscoverCommandsReceivedCommandStaticProperties
  extends ZigbeeGeneralCommandSpecialization {
  readonly command: 0x11;
}

export type ZigbeeDiscoverCommandsReceivedCommand = Specialize<
  ZigbeeCommand,
  ZigbeeDiscoverCommandsReceivedCommandStaticProperties
>;

export const ZIGBEE_DISCOVER_COMMANDS_RECEIVED_COMMAND: ZigbeeDiscoverCommandsReceivedCommandStaticProperties =
  Object.freeze({
    ...ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES,
    command: 0x11,
  });
