2.5.18 Discover Commands Received Command
