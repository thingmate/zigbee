import { type Abortable, abortableContext } from '@xstd/abortable';
import { Decoder, Encoder } from '@xstd/codec';
import { isSpecialisationOf } from '../../../../../../misc/__specialization/is-specialisation-of.js';
import { type ZigbeeResource } from '../../../../__resource/zigbee-resource.js';
import { type ZigbeeCommand } from '../../../../command/zigbee-command.js';
import { decodeZigbeeDiscoverCommandsReceivedResponsePayload } from '../../0x12--discover-commands-received-response/types/zigbee-discover-commands-received-response-payload/codec/decode-zigbee-discover-commands-received-response-payload.js';
import { type ZigbeeDiscoverCommandsReceivedResponsePayload } from '../../0x12--discover-commands-received-response/types/zigbee-discover-commands-received-response-payload/zigbee-discover-commands-received-response-payload.js';
import { ZIGBEE_DISCOVER_COMMANDS_RECEIVED_RESPONSE_COMMAND } from '../../0x12--discover-commands-received-response/zigbee-discover-commands-received-response-command.js';
import { encodeZigbeeDiscoverCommandsReceivedPayload } from '../types/zigbee-discover-commands-received-payload/codec/encode-zigbee-discover-commands-received-payload.js';
import { type ZigbeeDiscoverCommandsReceivedPayload } from '../types/zigbee-discover-commands-received-payload/zigbee-discover-commands-received-payload.js';
import { ZIGBEE_DISCOVER_COMMANDS_RECEIVED_COMMAND } from '../zigbee-discover-commands-received-command.js';

export interface ZigbeeDiscoverCommandsOptions
  extends Omit<ZigbeeCommand, 'clusterSpecific' | 'direction' | 'command' | 'payload'>,
    ZigbeeDiscoverCommandsReceivedPayload,
    Abortable {
  readonly adapter: ZigbeeResource;
}

/*
TODO handle error: 2.5.12 Default Response Command
// 16:00:57.047 ZIG: {"ZbZCLReceived":{"groupid":0,"clusterid":"0x0006","srcaddr":"0xC8C5","srcendpoint":1,"dstendpoint":1,"wasbroadcast":0,"LinkQuality":79,"securityuse":0,"seqnumber":100,"fc":"0x18","frametype":0,"direction":1,"disableresp":1,"manuf":"0x0000","transact":215,"cmdid":"0x0B","payload":"1101"}}
 */
export function zigbeeDiscoverCommandsReceived({
  adapter,
  startCommandIdentifier,
  maximumCommandIdentifiers,
  signal,
  ...requestCommand
}: ZigbeeDiscoverCommandsOptions): Promise<ZigbeeDiscoverCommandsReceivedResponsePayload> {
  return abortableContext(
    async (signal: AbortSignal): Promise<ZigbeeDiscoverCommandsReceivedResponsePayload> => {
      return (
        await Promise.all([
          adapter.receiver
            .mapFilter(
              (
                responseCommand: ZigbeeCommand,
              ): ZigbeeDiscoverCommandsReceivedResponsePayload | null => {
                return (
                    isSpecialisationOf(responseCommand, {
                      ...requestCommand,
                      ...ZIGBEE_DISCOVER_COMMANDS_RECEIVED_RESPONSE_COMMAND,
                      direction: 'server-to-client',
                    })
                  ) ?
                    Decoder.decode(
                      responseCommand.payload,
                      decodeZigbeeDiscoverCommandsReceivedResponsePayload,
                    )
                  : null;
              },
            )
            .first({ signal }),
          adapter.send({
            ...requestCommand,
            ...ZIGBEE_DISCOVER_COMMANDS_RECEIVED_COMMAND,
            clusterSpecific: false,
            direction: 'client-to-server',
            payload: Encoder.encode(
              { startCommandIdentifier, maximumCommandIdentifiers },
              encodeZigbeeDiscoverCommandsReceivedPayload,
            ),
            signal,
          }),
        ])
      )[0];
    },
    { signal },
  );
}
