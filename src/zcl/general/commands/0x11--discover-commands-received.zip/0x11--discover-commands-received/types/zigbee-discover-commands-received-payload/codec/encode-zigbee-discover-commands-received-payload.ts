import { type Encoder } from '@xstd/codec';
import { type ZigbeeDiscoverCommandsReceivedPayload } from '../zigbee-discover-commands-received-payload.js';

export function encodeZigbeeDiscoverCommandsReceivedPayload(
  encoder: Encoder,
  { startCommandIdentifier, maximumCommandIdentifiers }: ZigbeeDiscoverCommandsReceivedPayload,
): void {
  encoder.uint8(startCommandIdentifier).uint8(maximumCommandIdentifiers);
}
