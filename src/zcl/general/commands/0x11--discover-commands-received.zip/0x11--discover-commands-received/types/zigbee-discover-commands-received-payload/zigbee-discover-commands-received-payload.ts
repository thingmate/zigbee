export interface ZigbeeDiscoverCommandsReceivedPayload {
  readonly startCommandIdentifier: number; // u8
  readonly maximumCommandIdentifiers: number; // u8
}
