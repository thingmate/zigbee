import { type Specialize } from '../../../../../misc/__specialization/specialize.js';
import { type ZigbeeCommand } from '../../../command/zigbee-command.js';
import {
  ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES,
  type ZigbeeGeneralCommandSpecialization,
} from '../zigbee-general-command.js';

export interface ZigbeeDiscoverCommandsGeneratedResponseCommandStaticProperties
  extends ZigbeeGeneralCommandSpecialization {
  readonly command: 0x14;
}

export type ZigbeeDiscoverCommandsGeneratedResponseCommand = Specialize<
  ZigbeeCommand,
  ZigbeeDiscoverCommandsGeneratedResponseCommandStaticProperties
>;

export const ZIGBEE_DISCOVER_COMMANDS_GENERATED_RESPONSE_COMMAND: ZigbeeDiscoverCommandsGeneratedResponseCommandStaticProperties =
  Object.freeze({
    ...ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES,
    command: 0x14,
  });
