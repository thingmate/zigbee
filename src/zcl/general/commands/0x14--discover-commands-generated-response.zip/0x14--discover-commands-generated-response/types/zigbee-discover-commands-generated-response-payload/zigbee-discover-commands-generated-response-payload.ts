export interface ZigbeeDiscoverCommandsGeneratedResponsePayload {
  readonly discoveryComplete: boolean;
  readonly commands: readonly number[];
}
