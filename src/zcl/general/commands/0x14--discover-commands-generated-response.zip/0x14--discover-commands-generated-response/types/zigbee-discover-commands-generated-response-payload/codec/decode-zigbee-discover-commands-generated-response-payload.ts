import { type Decoder } from '@xstd/codec';
import { type ZigbeeDiscoverCommandsGeneratedResponsePayload } from '../zigbee-discover-commands-generated-response-payload.js';

export function decodeZigbeeDiscoverCommandsGeneratedResponsePayload(
  decoder: Decoder,
): ZigbeeDiscoverCommandsGeneratedResponsePayload {
  const discoveryComplete: boolean = decoder.uint8() === 1;

  const commands: number[] = [];

  while (!decoder.done) {
    commands.push(decoder.uint8());
  }

  return {
    discoveryComplete,
    commands,
  };
}
