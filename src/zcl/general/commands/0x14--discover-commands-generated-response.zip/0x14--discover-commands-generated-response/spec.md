2.5.21 Discover Commands Generated Response
