export interface ZigbeeDiscoverCommandsReceivedResponsePayload {
  readonly discoveryComplete: boolean;
  readonly commands: readonly number[];
}
