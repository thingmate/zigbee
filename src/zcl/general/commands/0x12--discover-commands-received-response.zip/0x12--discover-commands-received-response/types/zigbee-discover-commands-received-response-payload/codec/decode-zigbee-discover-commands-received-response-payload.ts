import { type Decoder } from '@xstd/codec';
import { type ZigbeeDiscoverCommandsReceivedResponsePayload } from '../zigbee-discover-commands-received-response-payload.js';

export function decodeZigbeeDiscoverCommandsReceivedResponsePayload(
  decoder: Decoder,
): ZigbeeDiscoverCommandsReceivedResponsePayload {
  const discoveryComplete: boolean = decoder.uint8() === 1;

  const commands: number[] = [];

  while (!decoder.done) {
    commands.push(decoder.uint8());
  }

  return {
    discoveryComplete,
    commands,
  };
}
