import { type Specialize } from '../../../../../misc/__specialization/specialize.js';
import { type ZigbeeCommand } from '../../../command/zigbee-command.js';
import {
  ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES,
  type ZigbeeGeneralCommandSpecialization,
} from '../zigbee-general-command.js';

export interface ZigbeeDiscoverCommandsReceivedResponseCommandStaticProperties
  extends ZigbeeGeneralCommandSpecialization {
  readonly command: 0x12;
}

export type ZigbeeDiscoverCommandsReceivedResponseCommand = Specialize<
  ZigbeeCommand,
  ZigbeeDiscoverCommandsReceivedResponseCommandStaticProperties
>;

export const ZIGBEE_DISCOVER_COMMANDS_RECEIVED_RESPONSE_COMMAND: ZigbeeDiscoverCommandsReceivedResponseCommandStaticProperties =
  Object.freeze({
    ...ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES,
    command: 0x12,
  });
