5.2 Color Control Cluster
