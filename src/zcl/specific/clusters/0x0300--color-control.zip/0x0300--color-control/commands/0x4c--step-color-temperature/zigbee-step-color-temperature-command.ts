export interface ZigbeeStepColorTemperatureCommand {
  readonly stepMode: 'up' | 'down';
  readonly stepSize: number; // u16
  readonly transitionTime: number; // u16 -> 1/10ths of a second
  readonly colorTemperatureMinimumMireds: number; // u16
  readonly colorTemperatureMaximumMireds: number; // u16
}
