import { ZigbeeCommand } from '../../../../../command/zigbee-command.js';
import {
  isZigbeeCluster0x0300Command,
  IsZigbeeCluster0x0300CommandOptions,
} from '../is-zigbee-cluster-0x0300-command.js';

export type IsZigbeeCluster0x0300Command0x4cOptions = IsZigbeeCluster0x0300CommandOptions &
  Pick<ZigbeeCommand, 'command'>;

export function isZigbeeCluster0x0300Command0x4c(
  command: IsZigbeeCluster0x0300Command0x4cOptions,
): boolean {
  return isZigbeeCluster0x0300Command(command) && command.command === 0x4c;
}
