import { Decoder } from '@xstd/codec';
import { decodeZigbeeDataTypeMap8 } from '../../../../../data/0x18--map8/decode-zigbee-data-type-map8.js';
import { decodeZigbeeDataTypeUint16 } from '../../../../../data/0x21--uint16/decode-zigbee-data-type-uint16.js';
import { ZigbeeStepColorTemperatureCommand } from './zigbee-step-color-temperature-command.js';

export function decodeZigbeeCluster0x0300Command0x4c(
  decoder: Decoder,
): ZigbeeStepColorTemperatureCommand {
  return {
    stepMode: decodeZigbeeDataTypeMap8(decoder) === 0x01 ? 'up' : 'down',
    stepSize: decodeZigbeeDataTypeUint16(decoder),
    transitionTime: decodeZigbeeDataTypeUint16(decoder),
    colorTemperatureMinimumMireds: decodeZigbeeDataTypeUint16(decoder),
    colorTemperatureMaximumMireds: decodeZigbeeDataTypeUint16(decoder),
  };
}
