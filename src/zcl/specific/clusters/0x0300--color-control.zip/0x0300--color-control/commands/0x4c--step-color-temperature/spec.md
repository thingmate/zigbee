5.2.2.3.21 Step Color Temperature Command
