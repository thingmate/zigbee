import { Decoder } from '@xstd/codec';
import { decodeZigbeeDataTypeUint8 } from '../../../../../data/0x20--uint8/decode-zigbee-data-type-uint8.js';
import { decodeZigbeeDataTypeUint16 } from '../../../../../data/0x21--uint16/decode-zigbee-data-type-uint16.js';
import { decodeZigbeeCluster0x0300Command0x00Direction } from './decode-zigbee-cluster-0x0300-command-0x00-direction.js';
import { ZigbeeMoveToHueCommand } from './zigbee-move-to-hue-command.js';

export function decodeZigbeeCluster0x0300Command0x00(decoder: Decoder): ZigbeeMoveToHueCommand {
  return {
    hue: decodeZigbeeDataTypeUint8(decoder),
    direction: decodeZigbeeCluster0x0300Command0x00Direction(decoder),
    transitionTime: decodeZigbeeDataTypeUint16(decoder),
  };
}
