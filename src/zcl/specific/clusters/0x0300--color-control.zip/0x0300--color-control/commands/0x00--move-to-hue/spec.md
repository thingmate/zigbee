5.2.2.3.3 Move to Hue Command
