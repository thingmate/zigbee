import { Decoder } from '@xstd/codec';
import { decodeZigbeeDataTypeMap8 } from '../../../../../data/0x18--map8/decode-zigbee-data-type-map8.js';
import { ZigbeeMoveToHueCommandDirection } from './zigbee-move-to-hue-command.js';

const ZigbeeMoveToHueCommandDirectionMap: readonly ZigbeeMoveToHueCommandDirection[] = [
  'shortest-distance',
  'longest-distance',
  'up',
  'down',
];

export function decodeZigbeeCluster0x0300Command0x00Direction(
  decoder: Decoder,
): ZigbeeMoveToHueCommandDirection {
  return ZigbeeMoveToHueCommandDirectionMap[decodeZigbeeDataTypeMap8(decoder)];
}
