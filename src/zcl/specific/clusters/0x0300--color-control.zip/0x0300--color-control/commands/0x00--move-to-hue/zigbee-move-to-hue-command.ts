export interface ZigbeeMoveToHueCommand {
  readonly hue: number; // u8
  readonly direction: ZigbeeMoveToHueCommandDirection;
  readonly transitionTime: number; // u16 -> 1/10ths of a second
}

export type ZigbeeMoveToHueCommandDirection =
  | 'shortest-distance'
  | 'longest-distance'
  | 'up'
  | 'down';
