import { ZigbeeCommand } from '../../../../command/zigbee-command.js';
import {
  isZigbeeClusterCommand,
  IsZigbeeClusterCommandOptions,
} from '../../is-zigbee-cluster-command.js';

export type IsZigbeeCluster0x0300CommandOptions = IsZigbeeClusterCommandOptions &
  Pick<ZigbeeCommand, 'cluster'>;

export function isZigbeeCluster0x0300Command(
  command: IsZigbeeCluster0x0300CommandOptions,
): boolean {
  return isZigbeeClusterCommand(command) && command.cluster === 0x0300;
}
