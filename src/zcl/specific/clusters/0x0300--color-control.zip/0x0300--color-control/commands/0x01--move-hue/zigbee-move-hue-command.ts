export interface ZigbeeMoveHueCommand {
  readonly mode: ZigbeeMoveHueCommandMode;
  readonly rate: number; // u8
}

export type ZigbeeMoveHueCommandMode = 'stop' | 'up' | 'down';
