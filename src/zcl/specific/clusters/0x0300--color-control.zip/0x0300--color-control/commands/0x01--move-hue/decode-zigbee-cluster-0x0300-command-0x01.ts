import { Decoder } from '@xstd/codec';
import { decodeZigbeeDataTypeUint8 } from '../../../../../data/0x20--uint8/decode-zigbee-data-type-uint8.js';
import { decodeZigbeeCluster0x0300Command0x01Mode } from './decode-zigbee-cluster-0x0300-command-0x01-mode.js';
import { ZigbeeMoveHueCommand } from './zigbee-move-hue-command.js';

export function decodeZigbeeCluster0x0300Command0x01(decoder: Decoder): ZigbeeMoveHueCommand {
  return {
    mode: decodeZigbeeCluster0x0300Command0x01Mode(decoder),
    rate: decodeZigbeeDataTypeUint8(decoder),
  };
}
