import { Decoder } from '@xstd/codec';
import { decodeZigbeeDataTypeEnum8 } from '../../../../../data/0x30--enum8/decode-zigbee-data-type-enum8.js';
import { ZigbeeMoveHueCommandMode } from './zigbee-move-hue-command.js';

const ZigbeeMoveHueCommandModeMap: readonly ZigbeeMoveHueCommandMode[] = [
  'stop',
  'up',
  undefined as any,
  'down',
];

export function decodeZigbeeCluster0x0300Command0x01Mode(
  decoder: Decoder,
): ZigbeeMoveHueCommandMode {
  return ZigbeeMoveHueCommandModeMap[decodeZigbeeDataTypeEnum8(decoder)];
}
