5.2.2.3.4 Move Hue Command
