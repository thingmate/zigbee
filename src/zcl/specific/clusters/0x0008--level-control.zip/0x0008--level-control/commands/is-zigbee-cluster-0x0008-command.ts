import { ZigbeeCommand } from '../../../../command/zigbee-command.js';
import {
  isZigbeeClusterCommand,
  IsZigbeeClusterCommandOptions,
} from '../../is-zigbee-cluster-command.js';

export type IsZigbeeCluster0x0008CommandOptions = IsZigbeeClusterCommandOptions &
  Pick<ZigbeeCommand, 'cluster'>;

export function isZigbeeCluster0x0008Command(
  command: IsZigbeeCluster0x0008CommandOptions,
): boolean {
  return isZigbeeClusterCommand(command) && command.cluster === 0x0008;
}
