3.10.2.4.3 Step Command
