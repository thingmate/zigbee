import { EntityEvent } from '@thingmate/entity';
import { Abortable } from '@xstd/abortable';
import type { EmitterFactory } from '@xstd/resource';
import { ZigbeeDeviceEntityOptions } from '../../../../../../__entities/device/zigbee-device-entity-options.js';
import { ZigbeeResource } from '../../../../../__resource/zigbee-resource.js';
import { ZigbeeStepCommand } from './zigbee-step-command.js';

// TODO
export class ZigbeeStepAction extends EntityEvent<ZigbeeStepCommand> {
  readonly #adapter: ZigbeeResource;
  readonly #device: number;
  readonly #observer: EmitterFactory<ZigbeeStepCommand>;

  constructor({ adapter, device }: ZigbeeDeviceEntityOptions) {
    super();

    this.#adapter = adapter;
    this.#device = device;

    this.closesWith(adapter);
  }

  override invoke(options?: Abortable): Promise<void> {
    return this.#adapter.send({
      ...options,
      device: this.#device,
      endpoint: 1,
      cluster: 0x0006,
      clusterSpecific: true,
      direction: 'client-to-server',
      command: 0x02,
      payload: new Uint8Array(0),
    });
  }
}
