export interface ZigbeeStepCommand {
  readonly stepMode: 'up' | 'down';
  readonly stepSize: number; // u16
  readonly transitionTime: number; // u16 -> 1/10ths of a second
}
