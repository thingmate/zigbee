import { Decoder } from '@xstd/codec';
import { decodeZigbeeDataTypeUint8 } from '../../../../../data/0x20--uint8/decode-zigbee-data-type-uint8.js';
import { decodeZigbeeDataTypeUint16 } from '../../../../../data/0x21--uint16/decode-zigbee-data-type-uint16.js';
import { decodeZigbeeDataTypeEnum8 } from '../../../../../data/0x30--enum8/decode-zigbee-data-type-enum8.js';
import { ZigbeeStepCommand } from './zigbee-step-command.js';

export function decodeZigbeeCluster0x0008Command0x02(decoder: Decoder): ZigbeeStepCommand {
  return {
    stepMode: decodeZigbeeDataTypeEnum8(decoder) === 0x00 ? 'up' : 'down',
    stepSize: decodeZigbeeDataTypeUint8(decoder),
    transitionTime: decodeZigbeeDataTypeUint16(decoder),
  };
}
