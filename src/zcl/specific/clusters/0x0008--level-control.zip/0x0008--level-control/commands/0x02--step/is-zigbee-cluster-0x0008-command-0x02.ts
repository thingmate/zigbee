import { ZigbeeCommand } from '../../../../../command/zigbee-command.js';
import { IsZigbeeCluster0x0300CommandOptions } from '../../../0x0300--color-control/commands/is-zigbee-cluster-0x0300-command.js';
import { isZigbeeCluster0x0008Command } from '../is-zigbee-cluster-0x0008-command.js';

export type IsZigbeeCluster0x0008Command0x02Options = IsZigbeeCluster0x0300CommandOptions &
  Pick<ZigbeeCommand, 'command'>;

export function isZigbeeCluster0x0008Command0x02(
  command: IsZigbeeCluster0x0008Command0x02Options,
): boolean {
  return isZigbeeCluster0x0008Command(command) && command.command === 0x01;
}
