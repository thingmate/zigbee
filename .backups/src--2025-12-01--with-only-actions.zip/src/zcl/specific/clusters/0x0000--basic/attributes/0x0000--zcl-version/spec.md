3.2.2.2.1 ZCLVersion Attribute
