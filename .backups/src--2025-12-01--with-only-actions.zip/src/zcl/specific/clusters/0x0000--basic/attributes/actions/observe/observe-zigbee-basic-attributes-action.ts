import { type ObserveZigbeeAttributesAction } from '../../../../../../general/attributes/actions/observe-attributes/observe-zigbee-attributes-action.js';

export type ObserveZigbeeBasicAttributesAction = ObserveZigbeeAttributesAction;
