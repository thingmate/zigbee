import { createReadZigbeeAttributeUsingReadZigbeeAttributes } from '../../../../../../../../../general/attributes/actions/read-attribute/implementations/using-read-zigbee-attributes/create-read-zigbee-attribute-using-read-zigbee-attributes.js';
import { type ReadZigbeeBasicAttributesAction } from '../../../../../actions/read/read-zigbee-basic-attributes-action.js';
import { ZIGBEE_CLUSTER_0x0000_ATTRIBUTE_0x0004 } from '../../../../zigbee-cluster-0x0000-attribute-0x0004.js';
import { type ReadZigbeeManufacturerNameAttributeAction } from '../../read-zigbee-manufacturer-name-attribute-action.js';

export interface CreateReadZigbeeManufacturerNameAttributeActionUsingReadZigbeeBasicAttributesActionOptions {
  readonly read: ReadZigbeeBasicAttributesAction;
}

export function createReadZigbeeManufacturerNameAttributeActionUsingReadZigbeeBasicAttributesAction({
  read,
}: CreateReadZigbeeManufacturerNameAttributeActionUsingReadZigbeeBasicAttributesActionOptions): ReadZigbeeManufacturerNameAttributeAction {
  return createReadZigbeeAttributeUsingReadZigbeeAttributes<string>({
    read,
    attributeId: ZIGBEE_CLUSTER_0x0000_ATTRIBUTE_0x0004,
  });
}
