import {
  createObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedProperties,
  type CreateObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedPropertiesOptionsForConsumer,
} from '../../../../../../../../general/attributes/actions/observe-attributes/filtered-by-cluster/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-attributes-action-filtered-by-cluster-using-observe-zigbee-command-action-for-predefined-properties.js';
import { ZIGBEE_CLUSTER_0x0000 } from '../../../../../zigbee-cluster-0x0000.js';
import { type ObserveZigbeeBasicAttributesAction } from '../../observe-zigbee-basic-attributes-action.js';

export interface CreateObserveZigbeeBasicAttributesActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions
  extends CreateObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedPropertiesOptionsForConsumer {}

export function createObserveZigbeeBasicAttributesActionUsingObserveZigbeeCommandActionForPredefinedProperties({
  observe,
}: CreateObserveZigbeeBasicAttributesActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions): ObserveZigbeeBasicAttributesAction {
  return createObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedProperties(
    {
      observe,
      cluster: ZIGBEE_CLUSTER_0x0000,
    },
  );
}
