import { type ReadZigbeeAttributeAction } from '../../../../../../../general/attributes/actions/read-attribute/read-zigbee-attribute-action.js';

export type ReadZigbeeManufacturerNameAttributeAction = ReadZigbeeAttributeAction<string>;
