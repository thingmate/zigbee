import { type ReadZigbeeAttributesAction } from '../../../../../../general/attributes/actions/read-attributes/read-zigbee-attributes-action.js';

export type ReadZigbeeBasicAttributesAction = ReadZigbeeAttributesAction;
