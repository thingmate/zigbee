3.2.2.3 Commands Received
