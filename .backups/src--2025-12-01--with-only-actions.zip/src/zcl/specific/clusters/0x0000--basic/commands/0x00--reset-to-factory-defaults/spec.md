3.2.2.3.1 Reset to Factory Defaults Command
