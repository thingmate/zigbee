export const ZIGBEE_CLUSTER_0x0000 = 0x0000;

export type ZigbeeCluster0x0000 = typeof ZIGBEE_CLUSTER_0x0000;
