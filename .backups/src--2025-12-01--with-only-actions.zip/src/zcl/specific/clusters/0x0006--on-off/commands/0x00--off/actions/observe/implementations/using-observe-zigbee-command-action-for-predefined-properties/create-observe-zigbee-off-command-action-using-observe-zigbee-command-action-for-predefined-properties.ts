import { type ObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../../../command/subsets/for-predefined-properties/actions/observe/observe-zigbee-command-action-for-predefined-properties.js';
import { createObserveZigbeeEmptyPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../../../command/subsets/payload/empty/actions/observe/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-empty-payload-action-using-observe-zigbee-command-action-for-predefined-properties.js';
import {
  ZIGBEE_CLUSTER_0x0006_COMMAND_0x00_PREDEFINED_PROPERTIES,
  type ZigbeeCluster0x0006Command0x00PredefinedProperties,
} from '../../../../zigbee-cluster-0x0006-command-0x00.js';

import { type ObserveZigbeeOffCommandAction } from '../../observe-zigbee-off-command-action.js';

export interface CreateObserveZigbeeOffCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions {
  readonly observe: ObserveZigbeeCommandActionForPredefinedProperties<ZigbeeCluster0x0006Command0x00PredefinedProperties>;
}

export function createObserveZigbeeOffCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties({
  observe,
}: CreateObserveZigbeeOffCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions): ObserveZigbeeOffCommandAction {
  return createObserveZigbeeEmptyPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties(
    {
      observe,
      commandPredefinedProperties: ZIGBEE_CLUSTER_0x0006_COMMAND_0x00_PREDEFINED_PROPERTIES,
    },
  );
}
