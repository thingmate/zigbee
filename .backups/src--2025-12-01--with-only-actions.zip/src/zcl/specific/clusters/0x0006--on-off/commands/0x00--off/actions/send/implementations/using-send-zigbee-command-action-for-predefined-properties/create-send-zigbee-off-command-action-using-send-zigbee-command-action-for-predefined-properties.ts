import { type SendZigbeeCommandActionForPredefinedProperties } from '../../../../../../../../../command/subsets/for-predefined-properties/actions/send/send-zigbee-command-action-for-predefined-properties.js';
import { createSendZigbeeEmptyPayloadActionUsingSendZigbeeCommandActionForPredefinedProperties } from '../../../../../../../../../command/subsets/payload/empty/actions/send/implementations/using-send-zigbee-command-action-for-predefined-properties/create-send-zigbee-empty-payload-action-using-send-zigbee-command-action-for-predefined-properties.js';
import {
  ZIGBEE_CLUSTER_0x0006_COMMAND_0x00_PREDEFINED_PROPERTIES,
  type ZigbeeCluster0x0006Command0x00PredefinedProperties,
} from '../../../../zigbee-cluster-0x0006-command-0x00.js';
import { type SendZigbeeOffCommandAction } from '../../send-zigbee-off-command-action.js';

export interface CreateSendZigbeeOffCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions {
  readonly send: SendZigbeeCommandActionForPredefinedProperties<ZigbeeCluster0x0006Command0x00PredefinedProperties>;
}

export function createSendZigbeeOffCommandActionUsingSendZigbeeCommandActionForPredefinedProperties({
  send,
}: CreateSendZigbeeOffCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions): SendZigbeeOffCommandAction {
  return createSendZigbeeEmptyPayloadActionUsingSendZigbeeCommandActionForPredefinedProperties({
    send,
    commandPredefinedProperties: ZIGBEE_CLUSTER_0x0006_COMMAND_0x00_PREDEFINED_PROPERTIES,
  });
}
