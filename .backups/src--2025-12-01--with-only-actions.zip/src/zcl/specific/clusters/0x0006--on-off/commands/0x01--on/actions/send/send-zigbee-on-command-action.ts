import { type SendZigbeeEmptyPayloadAction } from '../../../../../../../command/subsets/payload/empty/actions/send/send-zigbee-empty-payload-action.js';

export type SendZigbeeOnCommandAction = SendZigbeeEmptyPayloadAction;
