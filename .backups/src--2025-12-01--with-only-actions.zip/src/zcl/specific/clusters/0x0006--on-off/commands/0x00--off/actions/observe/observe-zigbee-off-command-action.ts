import { type ObserveZigbeeEmptyPayloadAction } from '../../../../../../../command/subsets/payload/empty/actions/observe/observe-zigbee-empty-payload-action.js';

export type ObserveZigbeeOffCommandAction = ObserveZigbeeEmptyPayloadAction;
