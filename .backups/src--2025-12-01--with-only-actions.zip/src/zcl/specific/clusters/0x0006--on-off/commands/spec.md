3.8.2.3 Commands Received
