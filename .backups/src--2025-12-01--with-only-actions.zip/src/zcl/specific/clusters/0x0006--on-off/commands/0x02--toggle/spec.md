3.8.2.3.3 Toggle Command
