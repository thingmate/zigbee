import { type ObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../../../command/subsets/for-predefined-properties/actions/observe/observe-zigbee-command-action-for-predefined-properties.js';
import { createObserveZigbeeEmptyPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../../../command/subsets/payload/empty/actions/observe/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-empty-payload-action-using-observe-zigbee-command-action-for-predefined-properties.js';
import {
  ZIGBEE_CLUSTER_0x0006_COMMAND_0x01_PREDEFINED_PROPERTIES,
  type ZigbeeCluster0x0006Command0x01PredefinedProperties,
} from '../../../../zigbee-cluster-0x0006-command-0x01.js';

import { type ObserveZigbeeOnCommandAction } from '../../observe-zigbee-on-command-action.js';

export interface CreateObserveZigbeeOnCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions {
  readonly observe: ObserveZigbeeCommandActionForPredefinedProperties<ZigbeeCluster0x0006Command0x01PredefinedProperties>;
}

export function createObserveZigbeeOnCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties({
  observe,
}: CreateObserveZigbeeOnCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions): ObserveZigbeeOnCommandAction {
  return createObserveZigbeeEmptyPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties(
    {
      observe,
      commandPredefinedProperties: ZIGBEE_CLUSTER_0x0006_COMMAND_0x01_PREDEFINED_PROPERTIES,
    },
  );
}
