import {
  createObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedProperties,
  type CreateObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedPropertiesOptionsForConsumer,
} from '../../../../../../../../general/attributes/actions/observe-attributes/filtered-by-cluster/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-attributes-action-filtered-by-cluster-using-observe-zigbee-command-action-for-predefined-properties.js';

import { ZIGBEE_CLUSTER_0x0006 } from '../../../../../zigbee-cluster-0x0006.js';
import { type ObserveZigbeeOnOffAttributesAction } from '../../observe-zigbee-on-off-attributes-action.js';

export interface CreateObserveZigbeeOnOffAttributesActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions
  extends CreateObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedPropertiesOptionsForConsumer {}

export function createObserveZigbeeOnOffAttributesActionUsingObserveZigbeeCommandActionForPredefinedProperties({
  observe,
}: CreateObserveZigbeeOnOffAttributesActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions): ObserveZigbeeOnOffAttributesAction {
  return createObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedProperties(
    {
      observe,
      cluster: ZIGBEE_CLUSTER_0x0006,
    },
  );
}
