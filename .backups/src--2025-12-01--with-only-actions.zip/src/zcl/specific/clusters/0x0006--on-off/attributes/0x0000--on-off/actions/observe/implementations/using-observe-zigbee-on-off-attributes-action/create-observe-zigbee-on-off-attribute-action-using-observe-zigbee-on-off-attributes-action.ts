import { createObserveZigbeeAttributeActionUsingObserveZigbeeAttributesAction } from '../../../../../../../../../general/attributes/actions/observe-attribute/implementations/using-observe-zigbee-attributes-action/create-observe-zigbee-attribute-action-using-observe-zigbee-attributes-action.js';
import { type ObserveZigbeeOnOffAttributesAction } from '../../../../../actions/observe/observe-zigbee-on-off-attributes-action.js';
import { ZIGBEE_CLUSTER_0x0006_ATTRIBUTE_0x0000 } from '../../../../zigbee-cluster-0x0006-attribute-0x0000.js';

import { type ObserveZigbeeOnOffAttributeAction } from '../../observe-zigbee-on-off-attribute-action.js';

export interface CreateObserveZigbeeOnOffAttributeActionUsingObserveZigbeeOnOffAttributesActionOptions {
  readonly observe: ObserveZigbeeOnOffAttributesAction;
}

export function createObserveZigbeeOnOffAttributeActionUsingObserveZigbeeOnOffAttributesAction({
  observe,
}: CreateObserveZigbeeOnOffAttributeActionUsingObserveZigbeeOnOffAttributesActionOptions): ObserveZigbeeOnOffAttributeAction {
  return createObserveZigbeeAttributeActionUsingObserveZigbeeAttributesAction({
    observe,
    attributeId: ZIGBEE_CLUSTER_0x0006_ATTRIBUTE_0x0000,
  });
}
