3.8.2.2.1 OnOff Attribute
