import { type DiscoverZigbeeAttributesAction } from '../../../../../../general/attributes/actions/discover-attributes/discover-zigbee-attributes-action.js';

export type DiscoverZigbeeOnOffAttributesAction = DiscoverZigbeeAttributesAction;
