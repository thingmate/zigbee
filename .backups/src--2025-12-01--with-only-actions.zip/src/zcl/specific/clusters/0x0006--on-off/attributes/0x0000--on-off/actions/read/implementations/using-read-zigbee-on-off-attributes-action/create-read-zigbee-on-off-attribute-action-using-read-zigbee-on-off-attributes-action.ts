import { createReadZigbeeAttributeUsingReadZigbeeAttributes } from '../../../../../../../../../general/attributes/actions/read-attribute/implementations/using-read-zigbee-attributes/create-read-zigbee-attribute-using-read-zigbee-attributes.js';
import { type ReadZigbeeOnOffAttributesAction } from '../../../../../actions/read/read-zigbee-on-off-attributes-action.js';
import { ZIGBEE_CLUSTER_0x0006_ATTRIBUTE_0x0000 } from '../../../../zigbee-cluster-0x0006-attribute-0x0000.js';
import { type ReadZigbeeOnOffAttributeAction } from '../../read-zigbee-on-off-attribute-action.js';

export interface CreateReadZigbeeOnOffAttributeActionUsingReadZigbeeOnOffAttributesActionOptions {
  readonly read: ReadZigbeeOnOffAttributesAction;
}

export function createReadZigbeeOnOffAttributeActionUsingReadZigbeeOnOffAttributesAction({
  read,
}: CreateReadZigbeeOnOffAttributeActionUsingReadZigbeeOnOffAttributesActionOptions): ReadZigbeeOnOffAttributeAction {
  return createReadZigbeeAttributeUsingReadZigbeeAttributes<boolean>({
    read,
    attributeId: ZIGBEE_CLUSTER_0x0006_ATTRIBUTE_0x0000,
  });
}
