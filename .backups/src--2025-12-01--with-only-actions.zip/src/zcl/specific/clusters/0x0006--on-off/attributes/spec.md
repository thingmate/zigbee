3.8.2.2 Attributes
