import { type ObserveZigbeeAttributeAction } from '../../../../../../../general/attributes/actions/observe-attribute/observe-zigbee-attribute-action.js';

export type ObserveZigbeeOnOffAttributeAction = ObserveZigbeeAttributeAction<boolean>;
