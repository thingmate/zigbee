import {
  createGetEntityValueActionFromCurrentAndNextActions,
  DEFAULT_ENTITY_PROPERTY,
} from '@thingmate/entity';
import { type Abortable } from '@xstd/abortable';
import { Action } from '@xstd/action';
import { type ObserveZigbeeOnOffAttributeAction } from '../../../../attributes/0x0000--on-off/actions/observe/observe-zigbee-on-off-attribute-action.js';
import { type ReadZigbeeOnOffAttributeAction } from '../../../../attributes/0x0000--on-off/actions/read/read-zigbee-on-off-attribute-action.js';
import { type SendZigbeeOffCommandAction } from '../../../../commands/0x00--off/actions/send/send-zigbee-off-command-action.js';
import { type SendZigbeeOnCommandAction } from '../../../../commands/0x01--on/actions/send/send-zigbee-on-command-action.js';
import { type ZigbeeOnOffEntityProperty } from '../../zigbee-on-off-entity-property.js';

export interface CreateZigbeeOnOffEntityPropertyUsingSubEntitiesOptions {
  readonly read: ReadZigbeeOnOffAttributeAction;
  readonly off: SendZigbeeOffCommandAction;
  readonly on: SendZigbeeOnCommandAction;
  readonly observe: ObserveZigbeeOnOffAttributeAction;
}

export function createZigbeeOnOffEntityPropertyUsingSubEntities({
  read,
  off,
  on,
  observe,
}: CreateZigbeeOnOffEntityPropertyUsingSubEntitiesOptions): ZigbeeOnOffEntityProperty {
  return {
    ...DEFAULT_ENTITY_PROPERTY,
    get: createGetEntityValueActionFromCurrentAndNextActions({
      current: read,
      next: observe,
    }),
    set: new Action<[value: boolean], void>(
      (value: boolean, options?: Abortable): Promise<void> => {
        if (value) {
          return on.invoke(options);
        } else {
          return off.invoke(options);
        }
      },
    ),
  };
}
