2.5.2 Read Attributes Response Command
