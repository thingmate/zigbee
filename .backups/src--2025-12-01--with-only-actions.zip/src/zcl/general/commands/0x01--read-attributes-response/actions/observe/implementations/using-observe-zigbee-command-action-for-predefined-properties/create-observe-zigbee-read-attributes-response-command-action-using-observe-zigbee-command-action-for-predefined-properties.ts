import { type ObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../command/subsets/for-predefined-properties/actions/observe/observe-zigbee-command-action-for-predefined-properties.js';
import { createObserveZigbeeDecodedPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../command/subsets/payload/decoded/actions/observe/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-decoded-payload-action-using-observe-zigbee-command-action-for-predefined-properties.js';
import { decodeZigbeeReadAttributesResponsePayload } from '../../../../types/zigbee-read-attributes-response-payload/codec/decode-zigbee-read-attributes-response-payload.js';
import {
  ZIGBEE_READ_ATTRIBUTES_RESPONSE_COMMAND_PREDEFINED_PROPERTIES,
  type ZigbeeReadAttributesResponseCommandPredefinedProperties,
} from '../../../../zigbee-read-attributes-response-command.js';
import { type ObserveZigbeeReadAttributesResponseCommandAction } from '../../observe-zigbee-read-attributes-response-command-action.js';

export interface CreateObserveZigbeeReadAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions {
  readonly observe: ObserveZigbeeCommandActionForPredefinedProperties<ZigbeeReadAttributesResponseCommandPredefinedProperties>;
}

export function createObserveZigbeeReadAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties({
  observe,
}: CreateObserveZigbeeReadAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions): ObserveZigbeeReadAttributesResponseCommandAction {
  return createObserveZigbeeDecodedPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties(
    {
      observe,
      commandPredefinedProperties: ZIGBEE_READ_ATTRIBUTES_RESPONSE_COMMAND_PREDEFINED_PROPERTIES,
      decode: decodeZigbeeReadAttributesResponsePayload,
    },
  );
}
