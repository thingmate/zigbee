import { type ObserveZigbeeDecodedPayloadAction } from '../../../../../command/subsets/payload/decoded/actions/observe/observe-zigbee-decoded-payload-action.js';
import { type ZigbeeReadAttributesResponsePayload } from '../../types/zigbee-read-attributes-response-payload/zigbee-read-attributes-response-payload.js';

export type ObserveZigbeeReadAttributesResponseCommandAction =
  ObserveZigbeeDecodedPayloadAction<ZigbeeReadAttributesResponsePayload>;
