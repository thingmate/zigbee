import { type ZigbeeReadAttributesStatusRecordField } from '../zigbee-read-attributes-status-record-field/zigbee-read-attributes-status-record-field.js';

export type ZigbeeReadAttributesResponsePayload = readonly ZigbeeReadAttributesStatusRecordField[];
