2.5.2.1 Read Attributes Response Command Frame Format
