export const ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES = Object.freeze({
  clusterSpecific: false,
});

export type ZigbeeGeneralCommandPredefinedProperties =
  typeof ZIGBEE_GENERAL_COMMAND_PREDEFINED_PROPERTIES;
