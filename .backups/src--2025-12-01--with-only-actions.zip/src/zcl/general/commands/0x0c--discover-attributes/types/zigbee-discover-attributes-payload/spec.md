2.5.13.1 Discover Attributes Command Frame Format
