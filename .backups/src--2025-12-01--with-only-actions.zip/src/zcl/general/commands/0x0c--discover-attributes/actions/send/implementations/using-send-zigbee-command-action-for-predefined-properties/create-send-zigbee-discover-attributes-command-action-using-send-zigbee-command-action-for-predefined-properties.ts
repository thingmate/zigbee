import { type SendZigbeeCommandActionForPredefinedProperties } from '../../../../../../../command/subsets/for-predefined-properties/actions/send/send-zigbee-command-action-for-predefined-properties.js';
import { createSendZigbeeDecodedPayloadActionUsingSendZigbeeActionForPredefinedCommand } from '../../../../../../../command/subsets/payload/decoded/actions/send/implementations/using-send-zigbee-action-for-predefined-command/create-send-zigbee-decoded-payload-action-using-send-zigbee-action-for-predefined-command.js';
import { encodeZigbeeDiscoverAttributesPayload } from '../../../../types/zigbee-discover-attributes-payload/codec/encode-zigbee-discover-attributes-payload.js';
import {
  ZIGBEE_DISCOVER_ATTRIBUTES_COMMAND_PREDEFINED_PROPERTIES,
  type ZigbeeDiscoverAttributesCommandPredefinedProperties,
} from '../../../../zigbee-discover-attributes-command.js';
import { type SendZigbeeDiscoverAttributesCommandAction } from '../../send-zigbee-discover-attributes-command-action.js';

export interface CreateSendZigbeeDiscoverAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions {
  readonly send: SendZigbeeCommandActionForPredefinedProperties<ZigbeeDiscoverAttributesCommandPredefinedProperties>;
}

export function createSendZigbeeDiscoverAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedProperties({
  send,
}: CreateSendZigbeeDiscoverAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions): SendZigbeeDiscoverAttributesCommandAction {
  return createSendZigbeeDecodedPayloadActionUsingSendZigbeeActionForPredefinedCommand({
    send,
    commandPredefinedProperties: ZIGBEE_DISCOVER_ATTRIBUTES_COMMAND_PREDEFINED_PROPERTIES,
    encode: encodeZigbeeDiscoverAttributesPayload,
  });
}
