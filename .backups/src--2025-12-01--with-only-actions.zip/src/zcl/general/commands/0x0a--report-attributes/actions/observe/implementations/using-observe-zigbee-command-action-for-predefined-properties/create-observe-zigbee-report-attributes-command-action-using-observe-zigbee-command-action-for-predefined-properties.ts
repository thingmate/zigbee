import { type ObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../command/subsets/for-predefined-properties/actions/observe/observe-zigbee-command-action-for-predefined-properties.js';
import { createObserveZigbeeDecodedPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../command/subsets/payload/decoded/actions/observe/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-decoded-payload-action-using-observe-zigbee-command-action-for-predefined-properties.js';
import { decodeZigbeeReportAttributesPayload } from '../../../../types/zigbee-report-attributes-payload/codec/decode-zigbee-report-attributes-payload.js';
import {
  ZIGBEE_REPORT_ATTRIBUTES_COMMAND_PREDEFINED_PROPERTIES,
  type ZigbeeReportAttributesCommandPredefinedProperties,
} from '../../../../zigbee-report-attributes-command.js';
import { type ObserveZigbeeReportAttributesCommandAction } from '../../observe-zigbee-report-attributes-command-action.js';

export interface CreateObserveZigbeeReportAttributesCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions {
  readonly observe: ObserveZigbeeCommandActionForPredefinedProperties<ZigbeeReportAttributesCommandPredefinedProperties>;
}

export function createObserveZigbeeReportAttributesCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties({
  observe,
}: CreateObserveZigbeeReportAttributesCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions): ObserveZigbeeReportAttributesCommandAction {
  return createObserveZigbeeDecodedPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties(
    {
      observe,
      commandPredefinedProperties: ZIGBEE_REPORT_ATTRIBUTES_COMMAND_PREDEFINED_PROPERTIES,
      decode: decodeZigbeeReportAttributesPayload,
    },
  );
}
