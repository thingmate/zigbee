import { type ObserveZigbeeDecodedPayloadAction } from '../../../../../command/subsets/payload/decoded/actions/observe/observe-zigbee-decoded-payload-action.js';
import { type ZigbeeReportAttributesPayload } from '../../types/zigbee-report-attributes-payload/zigbee-report-attributes-payload.js';

export type ObserveZigbeeReportAttributesCommandAction =
  ObserveZigbeeDecodedPayloadAction<ZigbeeReportAttributesPayload>;
