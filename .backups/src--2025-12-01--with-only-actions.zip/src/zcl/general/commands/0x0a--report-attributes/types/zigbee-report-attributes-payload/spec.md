2.5.11.1 Report Attributes Command Frame Format
