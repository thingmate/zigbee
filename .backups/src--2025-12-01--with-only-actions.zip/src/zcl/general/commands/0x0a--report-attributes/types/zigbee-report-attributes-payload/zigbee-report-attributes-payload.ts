import { type ZigbeeAttributeReportField } from '../zigbee-attribute-report-field/zigbee-attribute-report-field.js';

export type ZigbeeReportAttributesPayload = readonly ZigbeeAttributeReportField[];
