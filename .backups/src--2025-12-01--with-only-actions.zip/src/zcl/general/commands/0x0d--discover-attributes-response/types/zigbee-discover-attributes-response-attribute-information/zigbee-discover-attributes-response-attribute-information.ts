export interface ZigbeeDiscoverAttributesResponseAttributeInformation {
  readonly id: number; // u16
  readonly type: number; // u8
}
