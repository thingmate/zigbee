2.5.14.1 Discover Attributes Response Command Frame
Format
