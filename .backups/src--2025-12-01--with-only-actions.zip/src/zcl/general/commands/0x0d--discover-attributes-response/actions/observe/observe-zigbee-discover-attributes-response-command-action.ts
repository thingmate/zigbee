import { type ObserveZigbeeDecodedPayloadAction } from '../../../../../command/subsets/payload/decoded/actions/observe/observe-zigbee-decoded-payload-action.js';
import { type ZigbeeDiscoverAttributesResponsePayload } from '../../types/zigbee-discover-attributes-response-payload/zigbee-discover-attributes-response-payload.js';

export type ObserveZigbeeDiscoverAttributesResponseCommandAction =
  ObserveZigbeeDecodedPayloadAction<ZigbeeDiscoverAttributesResponsePayload>;
