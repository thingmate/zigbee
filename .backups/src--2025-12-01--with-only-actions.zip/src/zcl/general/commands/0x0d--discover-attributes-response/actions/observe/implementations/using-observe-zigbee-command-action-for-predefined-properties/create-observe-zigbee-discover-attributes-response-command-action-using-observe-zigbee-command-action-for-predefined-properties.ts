import { type ObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../command/subsets/for-predefined-properties/actions/observe/observe-zigbee-command-action-for-predefined-properties.js';
import { createObserveZigbeeDecodedPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../command/subsets/payload/decoded/actions/observe/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-decoded-payload-action-using-observe-zigbee-command-action-for-predefined-properties.js';
import { decodeZigbeeDiscoverAttributesResponsePayload } from '../../../../types/zigbee-discover-attributes-response-payload/codec/decode-zigbee-discover-attributes-response-payload.js';
import {
  ZIGBEE_DISCOVER_ATTRIBUTES_RESPONSE_COMMAND_PREDEFINED_PROPERTIES,
  type ZigbeeDiscoverAttributesResponseCommandPredefinedProperties,
} from '../../../../zigbee-discover-attributes-response-command.js';
import { type ObserveZigbeeDiscoverAttributesResponseCommandAction } from '../../observe-zigbee-discover-attributes-response-command-action.js';

export interface CreateObserveZigbeeDiscoverAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions {
  readonly observe: ObserveZigbeeCommandActionForPredefinedProperties<ZigbeeDiscoverAttributesResponseCommandPredefinedProperties>;
}

export function createObserveZigbeeDiscoverAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties({
  observe,
}: CreateObserveZigbeeDiscoverAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions): ObserveZigbeeDiscoverAttributesResponseCommandAction {
  return createObserveZigbeeDecodedPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties(
    {
      observe,
      commandPredefinedProperties:
        ZIGBEE_DISCOVER_ATTRIBUTES_RESPONSE_COMMAND_PREDEFINED_PROPERTIES,
      decode: decodeZigbeeDiscoverAttributesResponsePayload,
    },
  );
}
