export type ZigbeeReadAttributesPayload = readonly number /* u16 */[];
