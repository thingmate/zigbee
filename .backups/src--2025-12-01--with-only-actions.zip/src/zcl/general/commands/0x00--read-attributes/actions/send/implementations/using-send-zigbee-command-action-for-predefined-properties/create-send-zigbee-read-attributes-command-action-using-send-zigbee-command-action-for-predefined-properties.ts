import { type SendZigbeeCommandActionForPredefinedProperties } from '../../../../../../../command/subsets/for-predefined-properties/actions/send/send-zigbee-command-action-for-predefined-properties.js';
import { createSendZigbeeDecodedPayloadActionUsingSendZigbeeActionForPredefinedCommand } from '../../../../../../../command/subsets/payload/decoded/actions/send/implementations/using-send-zigbee-action-for-predefined-command/create-send-zigbee-decoded-payload-action-using-send-zigbee-action-for-predefined-command.js';
import { encodeZigbeeReadAttributesPayload } from '../../../../types/zigbee-read-attributes-payload/codec/encode-zigbee-read-attributes-payload.js';
import { type ZigbeeReadAttributesPayload } from '../../../../types/zigbee-read-attributes-payload/zigbee-read-attributes-payload.js';
import {
  ZIGBEE_READ_ATTRIBUTES_COMMAND_PREDEFINED_PROPERTIES,
  type ZigbeeReadAttributesCommandPredefinedProperties,
} from '../../../../zigbee-read-attributes-command.js';
import { type SendZigbeeReadAttributesCommandAction } from '../../send-zigbee-read-attributes-command-action.js';

export interface CreateSendZigbeeReadAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions {
  readonly send: SendZigbeeCommandActionForPredefinedProperties<ZigbeeReadAttributesCommandPredefinedProperties>;
}

export function createSendZigbeeReadAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedProperties({
  send,
}: CreateSendZigbeeReadAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions): SendZigbeeReadAttributesCommandAction {
  return createSendZigbeeDecodedPayloadActionUsingSendZigbeeActionForPredefinedCommand<
    ZigbeeReadAttributesCommandPredefinedProperties,
    ZigbeeReadAttributesPayload
  >({
    send,
    commandPredefinedProperties: ZIGBEE_READ_ATTRIBUTES_COMMAND_PREDEFINED_PROPERTIES,
    encode: encodeZigbeeReadAttributesPayload,
  });
}
