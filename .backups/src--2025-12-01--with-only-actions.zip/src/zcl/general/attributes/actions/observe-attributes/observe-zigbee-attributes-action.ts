import { type ObserveZigbeeReportAttributesCommandAction } from '../../../commands/0x0a--report-attributes/actions/observe/observe-zigbee-report-attributes-command-action.js';

export type ObserveZigbeeAttributesAction = ObserveZigbeeReportAttributesCommandAction;
