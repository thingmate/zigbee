import { type ObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../command/subsets/for-predefined-properties/actions/observe/observe-zigbee-command-action-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../../command/subsets/for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { createObserveZigbeeAttributesActionUsingObserveZigbeeCommandActionForPredefinedProperties } from '../../../implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-attributes-action-using-observe-zigbee-command-action-for-predefined-properties.js';
import { type ObserveZigbeeAttributesAction } from '../../../observe-zigbee-attributes-action.js';
import { type ZigbeeReportAttributesCommandPredefinedPropertiesWithCluster } from '../../zigbee-report-attributes-command-predefined-properties-with-cluster.js';

export interface CreateObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions {
  readonly observe: ObserveZigbeeCommandActionForPredefinedProperties<ZigbeeReportAttributesCommandPredefinedPropertiesWithCluster>;
  readonly cluster: number;
}

export function createObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedProperties({
  observe,
  cluster,
}: CreateObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions): ObserveZigbeeAttributesAction {
  return createObserveZigbeeAttributesActionUsingObserveZigbeeCommandActionForPredefinedProperties({
    observe: observe.filter(
      (
        command: ZigbeeCommandForPredefinedProperties<ZigbeeReportAttributesCommandPredefinedPropertiesWithCluster>,
      ): boolean => {
        return command.cluster === cluster;
      },
    ),
  });
}

/*---*/

export type CreateObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedPropertiesOptionsForConsumer =
  Omit<
    CreateObserveZigbeeAttributesActionFilteredByClusterUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions,
    'cluster'
  >;
