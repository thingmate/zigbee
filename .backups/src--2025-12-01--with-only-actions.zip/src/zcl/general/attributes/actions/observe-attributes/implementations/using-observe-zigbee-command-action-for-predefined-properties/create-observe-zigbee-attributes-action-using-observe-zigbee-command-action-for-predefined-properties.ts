import {
  createObserveZigbeeReportAttributesCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties,
  type CreateObserveZigbeeReportAttributesCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions,
} from '../../../../../commands/0x0a--report-attributes/actions/observe/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-report-attributes-command-action-using-observe-zigbee-command-action-for-predefined-properties.js';
import { type ObserveZigbeeAttributesAction } from '../../observe-zigbee-attributes-action.js';

export interface CreateObserveZigbeeAttributesActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions
  extends CreateObserveZigbeeReportAttributesCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions {}

export function createObserveZigbeeAttributesActionUsingObserveZigbeeCommandActionForPredefinedProperties(
  options: CreateObserveZigbeeAttributesActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions,
): ObserveZigbeeAttributesAction {
  return createObserveZigbeeReportAttributesCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties(
    options,
  );
}
