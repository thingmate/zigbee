import {
  createSendZigbeeReadAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedProperties,
  type CreateSendZigbeeReadAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions,
} from '../../../../../../../../commands/0x00--read-attributes/actions/send/implementations/using-send-zigbee-command-action-for-predefined-properties/create-send-zigbee-read-attributes-command-action-using-send-zigbee-command-action-for-predefined-properties.js';
import {
  createObserveZigbeeReadAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties,
  type CreateObserveZigbeeReadAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions,
} from '../../../../../../../../commands/0x01--read-attributes-response/actions/observe/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-read-attributes-response-command-action-using-observe-zigbee-command-action-for-predefined-properties.js';
import { type ReadZigbeeAttributesAdapter } from '../../read-zigbee-attributes-adapter.js';

export interface CreateReadZigbeeAttributesAdapterUsingZigbeeCommandAdapterOptions
  extends CreateSendZigbeeReadAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions,
    CreateObserveZigbeeReadAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions {}

export function createReadZigbeeAttributesAdapterUsingZigbeePredefinedCommandAdapter(
  options: CreateReadZigbeeAttributesAdapterUsingZigbeeCommandAdapterOptions,
): ReadZigbeeAttributesAdapter {
  return {
    send: createSendZigbeeReadAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedProperties(
      options,
    ),
    observe:
      createObserveZigbeeReadAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties(
        options,
      ),
  };
}
