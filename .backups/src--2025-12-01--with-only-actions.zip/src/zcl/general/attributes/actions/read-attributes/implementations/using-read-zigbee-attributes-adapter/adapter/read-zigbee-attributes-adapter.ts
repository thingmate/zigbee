import { type SendZigbeeReadAttributesCommandAction } from '../../../../../../commands/0x00--read-attributes/actions/send/send-zigbee-read-attributes-command-action.js';
import { type ObserveZigbeeReadAttributesResponseCommandAction } from '../../../../../../commands/0x01--read-attributes-response/actions/observe/observe-zigbee-read-attributes-response-command-action.js';

export interface ReadZigbeeAttributesAdapter {
  readonly send: SendZigbeeReadAttributesCommandAction;
  readonly observe: ObserveZigbeeReadAttributesResponseCommandAction;
}
