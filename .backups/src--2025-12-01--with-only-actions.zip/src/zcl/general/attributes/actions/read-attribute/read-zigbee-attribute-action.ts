import { type Action } from '@xstd/action';

export type ReadZigbeeAttributeAction<GValue> = Action<[], GValue>;
