import {
  createSendZigbeeDiscoverAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedProperties,
  type CreateSendZigbeeDiscoverAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions,
} from '../../../../../../../../commands/0x0c--discover-attributes/actions/send/implementations/using-send-zigbee-command-action-for-predefined-properties/create-send-zigbee-discover-attributes-command-action-using-send-zigbee-command-action-for-predefined-properties.js';
import {
  createObserveZigbeeDiscoverAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties,
  type CreateObserveZigbeeDiscoverAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions,
} from '../../../../../../../../commands/0x0d--discover-attributes-response/actions/observe/implementations/using-observe-zigbee-command-action-for-predefined-properties/create-observe-zigbee-discover-attributes-response-command-action-using-observe-zigbee-command-action-for-predefined-properties.js';
import { type DiscoverZigbeeAttributesAdapter } from '../../discover-zigbee-attributes-adapter.js';

export interface CreateDiscoverZigbeeAttributesAdapterUsingZigbeeCommandAdapterOptions
  extends CreateSendZigbeeDiscoverAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions,
    CreateObserveZigbeeDiscoverAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions {}

export function createDiscoverZigbeeAttributesAdapterUsingZigbeePredefinedCommandAdapter(
  options: CreateDiscoverZigbeeAttributesAdapterUsingZigbeeCommandAdapterOptions,
): DiscoverZigbeeAttributesAdapter {
  return {
    send: createSendZigbeeDiscoverAttributesCommandActionUsingSendZigbeeCommandActionForPredefinedProperties(
      options,
    ),
    observe:
      createObserveZigbeeDiscoverAttributesResponseCommandActionUsingObserveZigbeeCommandActionForPredefinedProperties(
        options,
      ),
  };
}
