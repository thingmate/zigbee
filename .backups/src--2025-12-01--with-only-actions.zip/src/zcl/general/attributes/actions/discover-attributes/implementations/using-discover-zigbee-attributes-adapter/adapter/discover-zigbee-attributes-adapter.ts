import { type SendZigbeeDiscoverAttributesCommandAction } from '../../../../../../commands/0x0c--discover-attributes/actions/send/send-zigbee-discover-attributes-command-action.js';
import { type ObserveZigbeeDiscoverAttributesResponseCommandAction } from '../../../../../../commands/0x0d--discover-attributes-response/actions/observe/observe-zigbee-discover-attributes-response-command-action.js';

export interface DiscoverZigbeeAttributesAdapter {
  readonly send: SendZigbeeDiscoverAttributesCommandAction;
  readonly observe: ObserveZigbeeDiscoverAttributesResponseCommandAction;
}
