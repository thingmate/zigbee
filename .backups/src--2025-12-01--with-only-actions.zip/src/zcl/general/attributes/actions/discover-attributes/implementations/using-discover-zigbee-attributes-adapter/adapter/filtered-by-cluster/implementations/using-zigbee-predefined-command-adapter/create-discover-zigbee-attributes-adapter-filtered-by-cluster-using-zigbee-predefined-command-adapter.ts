import { type Abortable } from '@xstd/abortable';
import { type ObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../../../../../command/subsets/for-predefined-properties/actions/observe/observe-zigbee-command-action-for-predefined-properties.js';
import { type SendZigbeeCommandActionForPredefinedProperties } from '../../../../../../../../../../command/subsets/for-predefined-properties/actions/send/send-zigbee-command-action-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../../../../../command/subsets/for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type ZigbeeDiscoverAttributesCommandPredefinedProperties } from '../../../../../../../../../commands/0x0c--discover-attributes/zigbee-discover-attributes-command.js';
import { type DiscoverZigbeeAttributesAdapter } from '../../../discover-zigbee-attributes-adapter.js';
import { createDiscoverZigbeeAttributesAdapterUsingZigbeePredefinedCommandAdapter } from '../../../implementations/using-zigbee-predefined-command-adapter/create-discover-zigbee-attributes-adapter-using-zigbee-predefined-command-adapter.js';
import { type ZigbeeDiscoverAttributesCommandPredefinedPropertiesWithCluster } from '../../zigbee-discover-attributes-command-predefined-properties-with-cluster.js';
import { type ZigbeeDiscoverAttributesResponseCommandPredefinedPropertiesWithCluster } from '../../zigbee-discover-attributes-response-command-predefined-properties-with-cluster.js';

export interface CreateDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptions {
  readonly send: SendZigbeeCommandActionForPredefinedProperties<ZigbeeDiscoverAttributesCommandPredefinedPropertiesWithCluster>;
  readonly observe: ObserveZigbeeCommandActionForPredefinedProperties<ZigbeeDiscoverAttributesResponseCommandPredefinedPropertiesWithCluster>;
  readonly cluster: number;
}

export function createDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapter({
  send,
  observe,
  cluster,
}: CreateDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptions): DiscoverZigbeeAttributesAdapter {
  return createDiscoverZigbeeAttributesAdapterUsingZigbeePredefinedCommandAdapter({
    send: send.mapArguments(
      (
        command: ZigbeeCommandForPredefinedProperties<ZigbeeDiscoverAttributesCommandPredefinedProperties>,
        options?: Abortable,
      ): [
        command: ZigbeeCommandForPredefinedProperties<ZigbeeDiscoverAttributesResponseCommandPredefinedPropertiesWithCluster>,
        options?: Abortable,
      ] => {
        return [
          {
            ...command,
            cluster,
          },
          options,
        ];
      },
    ),
    observe: observe.filter(
      (
        command: ZigbeeCommandForPredefinedProperties<ZigbeeDiscoverAttributesResponseCommandPredefinedPropertiesWithCluster>,
      ): boolean => {
        return command.cluster === cluster;
      },
    ),
  });
}

/*---*/

export type CreateDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptionsForConsumer =
  Omit<
    CreateDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptions,
    'cluster'
  >;
