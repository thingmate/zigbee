import { type Action } from '@xstd/action';

export type ObserveZigbeeAttributeAction<GValue> = Action<[], GValue>;
