import { NONE, type None } from '@xstd/none';
import { type ZigbeeReportAttributesPayload } from '../../../../../commands/0x0a--report-attributes/types/zigbee-report-attributes-payload/zigbee-report-attributes-payload.js';
import { type ObserveZigbeeAttributesAction } from '../../../observe-attributes/observe-zigbee-attributes-action.js';
import { type ObserveZigbeeAttributeAction } from '../../observe-zigbee-attribute-action.js';

export interface CreateObserveZigbeeAttributeActionUsingObserveZigbeeAttributesActionOptions {
  readonly observe: ObserveZigbeeAttributesAction;
  readonly attributeId: number /* u16 */;
}

export function createObserveZigbeeAttributeActionUsingObserveZigbeeAttributesAction<GValue>({
  observe,
  attributeId,
}: CreateObserveZigbeeAttributeActionUsingObserveZigbeeAttributesActionOptions): ObserveZigbeeAttributeAction<GValue> {
  return observe.then((payload: ZigbeeReportAttributesPayload): GValue | None => {
    for (const record of payload) {
      if (record.id === attributeId) {
        return record.value as GValue;
      }
    }
    return NONE;
  });
}
