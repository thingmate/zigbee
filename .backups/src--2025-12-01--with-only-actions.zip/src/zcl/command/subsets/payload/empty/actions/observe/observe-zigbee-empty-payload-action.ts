import { type Action } from '@xstd/action';

export type ObserveZigbeeEmptyPayloadAction = Action<[], void>;
