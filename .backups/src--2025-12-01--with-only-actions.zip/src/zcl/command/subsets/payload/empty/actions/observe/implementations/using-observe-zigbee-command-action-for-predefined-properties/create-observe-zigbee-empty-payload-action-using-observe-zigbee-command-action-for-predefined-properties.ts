import { NONE, type None } from '@xstd/none';
import { type ObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../for-predefined-properties/actions/observe/observe-zigbee-command-action-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type ObserveZigbeeEmptyPayloadAction } from '../../observe-zigbee-empty-payload-action.js';

export interface CreateObserveZigbeeEmptyPayloadActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
> {
  readonly observe: ObserveZigbeeCommandActionForPredefinedProperties<GPredefinedProperties>;
  readonly commandPredefinedProperties: GPredefinedProperties;
}

export function createObserveZigbeeEmptyPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
>({
  observe,
  commandPredefinedProperties,
}: CreateObserveZigbeeEmptyPayloadActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions<GPredefinedProperties>): ObserveZigbeeEmptyPayloadAction {
  const entries: readonly (readonly [key: string, value: unknown])[] = Object.entries(
    commandPredefinedProperties,
  );

  return observe.then(
    (command: ZigbeeCommandForPredefinedProperties<GPredefinedProperties>): void | None => {
      return entries.every(([key, value]: readonly [string, unknown]): boolean => {
        return value === Reflect.get(command, key);
      })
        ? undefined
        : NONE;
    },
  );
}
