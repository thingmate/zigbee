import { type Action } from '@xstd/action';

export type SendZigbeeEmptyPayloadAction = Action<[], void>;
