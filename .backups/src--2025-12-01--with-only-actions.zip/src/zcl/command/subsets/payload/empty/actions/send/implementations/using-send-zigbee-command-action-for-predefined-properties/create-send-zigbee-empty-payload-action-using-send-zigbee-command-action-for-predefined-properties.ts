import { type Abortable } from '@xstd/abortable';
import { type SendZigbeeCommandActionForPredefinedProperties } from '../../../../../../for-predefined-properties/actions/send/send-zigbee-command-action-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type SendZigbeeEmptyPayloadAction } from '../../send-zigbee-empty-payload-action.js';

export interface CreateSendZigbeeEmptyPayloadActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
> {
  readonly send: SendZigbeeCommandActionForPredefinedProperties<GPredefinedProperties>;
  readonly commandPredefinedProperties: GPredefinedProperties;
}

export function createSendZigbeeEmptyPayloadActionUsingSendZigbeeCommandActionForPredefinedProperties<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
>({
  send,
  commandPredefinedProperties,
}: CreateSendZigbeeEmptyPayloadActionUsingSendZigbeeCommandActionForPredefinedPropertiesOptions<GPredefinedProperties>): SendZigbeeEmptyPayloadAction {
  return send.mapArguments(
    (
      options?: Abortable,
    ): [
      command: ZigbeeCommandForPredefinedProperties<GPredefinedProperties>,
      options?: Abortable,
    ] => {
      return [
        {
          ...commandPredefinedProperties,
          payload: EMPTY_PAYLOAD,
        },
        options,
      ];
    },
  );
}

const EMPTY_PAYLOAD: Uint8Array = new Uint8Array(0);
