import { type DecodeFunction, Decoder } from '@xstd/codec';
import { type None, NONE } from '@xstd/none';
import { type ObserveZigbeeCommandActionForPredefinedProperties } from '../../../../../../for-predefined-properties/actions/observe/observe-zigbee-command-action-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type ObserveZigbeeDecodedPayloadAction } from '../../observe-zigbee-decoded-payload-action.js';

export interface CreateObserveZigbeeDecodedPayloadActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
  GPayload,
> {
  readonly observe: ObserveZigbeeCommandActionForPredefinedProperties<GPredefinedProperties>;
  readonly commandPredefinedProperties: GPredefinedProperties;
  readonly decode: DecodeFunction<GPayload>;
}

export function createObserveZigbeeDecodedPayloadActionUsingObserveZigbeeCommandActionForPredefinedProperties<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
  GPayload,
>({
  observe,
  commandPredefinedProperties,
  decode,
}: CreateObserveZigbeeDecodedPayloadActionUsingObserveZigbeeCommandActionForPredefinedPropertiesOptions<
  GPredefinedProperties,
  GPayload
>): ObserveZigbeeDecodedPayloadAction<GPayload> {
  const entries: readonly (readonly [key: string, value: unknown])[] = Object.entries(
    commandPredefinedProperties,
  );

  return observe.then(
    (command: ZigbeeCommandForPredefinedProperties<GPredefinedProperties>): GPayload | None => {
      return entries.every(([key, value]: readonly [string, unknown]): boolean => {
        return value === Reflect.get(command, key);
      })
        ? Decoder.decode(command.payload, decode)
        : NONE;
    },
  );
}
