import { type Abortable } from '@xstd/abortable';
import { type EncodeFunction, Encoder } from '@xstd/codec';
import { type SendZigbeeCommandActionForPredefinedProperties } from '../../../../../../for-predefined-properties/actions/send/send-zigbee-command-action-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type SendZigbeeDecodedPayloadAction } from '../../send-zigbee-decoded-payload-action.js';

export interface CreateSendZigbeeDecodedPayloadActionUsingSendZigbeeActionForPredefinedCommandOptions<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
  GPayload,
> {
  readonly send: SendZigbeeCommandActionForPredefinedProperties<GPredefinedProperties>;
  readonly commandPredefinedProperties: GPredefinedProperties;
  readonly encode: EncodeFunction<GPayload>;
}

export function createSendZigbeeDecodedPayloadActionUsingSendZigbeeActionForPredefinedCommand<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
  GPayload,
>({
  send,
  commandPredefinedProperties,
  encode,
}: CreateSendZigbeeDecodedPayloadActionUsingSendZigbeeActionForPredefinedCommandOptions<
  GPredefinedProperties,
  GPayload
>): SendZigbeeDecodedPayloadAction<GPayload> {
  return send.mapArguments(
    (
      payload: GPayload,
      options?: Abortable,
    ): [
      command: ZigbeeCommandForPredefinedProperties<GPredefinedProperties>,
      options?: Abortable,
    ] => {
      return [
        {
          ...commandPredefinedProperties,
          payload: Encoder.encode(payload, encode),
        },
        options,
      ];
    },
  );
}
