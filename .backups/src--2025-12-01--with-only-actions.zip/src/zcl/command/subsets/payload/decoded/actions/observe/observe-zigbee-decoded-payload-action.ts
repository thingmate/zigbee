import { type Action } from '@xstd/action';

export type ObserveZigbeeDecodedPayloadAction<GPayload> = Action<[], GPayload>;
