import { type Action } from '@xstd/action';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../zigbee-command-for-predefined-properties.js';

/**
 * Represents an ObserveZigbeeCommandAction emitting the minimal partial ZigbeeCommand to match some predefined properties.
 */
export type ObserveZigbeeCommandActionForPredefinedProperties<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
> = Action<[], ZigbeeCommandForPredefinedProperties<GPredefinedProperties>>;
