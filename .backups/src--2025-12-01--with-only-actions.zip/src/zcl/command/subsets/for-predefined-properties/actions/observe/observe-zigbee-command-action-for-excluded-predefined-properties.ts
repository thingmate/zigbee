import { type Action } from '@xstd/action';
import { type ZigbeeCommandForExcludedPredefinedProperties } from '../../zigbee-command-for-excluded-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../zigbee-command-for-predefined-properties-constraint.js';

/**
 * Represents a ObserveZigbeeCommandAction emitting a partial ZigbeeCommand without some predefined properties.
 */
export type ObserveZigbeeCommandActionForExcludedPredefinedProperties<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
> = Action<[], ZigbeeCommandForExcludedPredefinedProperties<GPredefinedProperties>>;
