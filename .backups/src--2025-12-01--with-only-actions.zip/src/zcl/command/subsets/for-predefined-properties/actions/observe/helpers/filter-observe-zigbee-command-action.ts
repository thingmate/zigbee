import { NONE, type None } from '@xstd/none';
import { type ObserveZigbeeCommandAction } from '../../../../../actions/observe/observe-zigbee-command-action.js';
import { type ZigbeeCommand } from '../../../../../zigbee-command.js';
import { type ZigbeeCommandForExcludedPredefinedProperties } from '../../../zigbee-command-for-excluded-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../zigbee-command-for-predefined-properties-constraint.js';
import { type ObserveZigbeeCommandActionForExcludedPredefinedProperties } from '../observe-zigbee-command-action-for-excluded-predefined-properties.js';

export function filterObserveZigbeeCommandAction<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
>(
  observe: ObserveZigbeeCommandAction,
  partialZigbeeCommand: GPredefinedProperties,
): ObserveZigbeeCommandActionForExcludedPredefinedProperties<GPredefinedProperties> {
  const entries: readonly (readonly [key: string, value: unknown])[] =
    Object.entries(partialZigbeeCommand);

  return observe.then(
    (
      input: ZigbeeCommand,
    ): ZigbeeCommandForExcludedPredefinedProperties<GPredefinedProperties> | None => {
      const output: ZigbeeCommand = Object.assign({}, input);

      for (const [key, value] of entries) {
        if (value === Reflect.get(input, key)) {
          Reflect.deleteProperty(output, key);
        } else {
          return NONE;
        }
      }

      return output as ZigbeeCommandForExcludedPredefinedProperties<GPredefinedProperties>;
    },
  );
}
