import { type ObserveZigbeeCommandAction } from '../actions/observe/observe-zigbee-command-action.js';
import { type SendZigbeeCommandAction } from '../actions/send/send-zigbee-command-action.js';

export interface ZigbeeCommandAdapter {
  readonly send: SendZigbeeCommandAction;
  readonly observe: ObserveZigbeeCommandAction;
}
