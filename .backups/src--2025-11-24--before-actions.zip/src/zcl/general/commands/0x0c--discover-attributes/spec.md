2.5.13 Discover Attributes Command
