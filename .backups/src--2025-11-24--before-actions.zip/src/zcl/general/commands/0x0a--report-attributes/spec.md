2.5.11 Report Attributes Command
