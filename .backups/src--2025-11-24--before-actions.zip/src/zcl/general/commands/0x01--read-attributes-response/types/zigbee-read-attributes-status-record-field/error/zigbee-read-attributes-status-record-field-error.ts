export interface ZigbeeReadAttributesStatusRecordFieldError {
  readonly id: number; // u16
  readonly status: 0x86; // u8
}
