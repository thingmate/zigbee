Figure 2-7. Format of the Read Attributes Status Record Field
