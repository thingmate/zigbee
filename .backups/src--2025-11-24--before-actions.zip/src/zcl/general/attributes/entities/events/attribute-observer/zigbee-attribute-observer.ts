import { type EntityEvent } from '@thingmate/entity';

export type ZigbeeAttributeObserver<GValue> = EntityEvent<GValue>;
