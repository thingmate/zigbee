import { type ZigbeeCommandObserverForPredefinedProperties } from '../../../../../../../../command/subsets/for-predefined-properties/entities/events/observer/zigbee-command-observer-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../../../command/subsets/for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { createZigbeeAttributesObserverUsingZigbeePredefinedCommandObserver } from '../../../implementations/using-zigbee-predefined-command-observer/create-zigbee-attributes-observer-using-zigbee-predefined-command-observer.js';
import { type ZigbeeAttributesObserver } from '../../../zigbee-attributes-observer.js';
import { type ZigbeeReportAttributesCommandPredefinedPropertiesWithCluster } from '../../zigbee-report-attributes-command-predefined-properties-with-cluster.js';

export interface CreateZigbeeAttributesObserverFilteredByClusterUsingZigbeePredefinedCommandObserverOptions {
  readonly observer: ZigbeeCommandObserverForPredefinedProperties<ZigbeeReportAttributesCommandPredefinedPropertiesWithCluster>;
  readonly cluster: number;
}

export function createZigbeeAttributesObserverFilteredByClusterUsingZigbeePredefinedCommandObserver({
  observer,
  cluster,
}: CreateZigbeeAttributesObserverFilteredByClusterUsingZigbeePredefinedCommandObserverOptions): ZigbeeAttributesObserver {
  return createZigbeeAttributesObserverUsingZigbeePredefinedCommandObserver({
    observer: observer.filter(
      (
        command: ZigbeeCommandForPredefinedProperties<ZigbeeReportAttributesCommandPredefinedPropertiesWithCluster>,
      ): boolean => {
        return command.cluster === cluster;
      },
    ),
  });
}

/*---*/

export type CreateZigbeeAttributesObserverFilteredByClusterUsingZigbeePredefinedCommandObserverOptionsForConsumer =
  Omit<
    CreateZigbeeAttributesObserverFilteredByClusterUsingZigbeePredefinedCommandObserverOptions,
    'cluster'
  >;
