import { type ZigbeeReportAttributesCommandObserver } from '../../../../commands/0x0a--report-attributes/entities/events/observer/zigbee-report-attributes-command-observer.js';

export type ZigbeeAttributesObserver = ZigbeeReportAttributesCommandObserver;
