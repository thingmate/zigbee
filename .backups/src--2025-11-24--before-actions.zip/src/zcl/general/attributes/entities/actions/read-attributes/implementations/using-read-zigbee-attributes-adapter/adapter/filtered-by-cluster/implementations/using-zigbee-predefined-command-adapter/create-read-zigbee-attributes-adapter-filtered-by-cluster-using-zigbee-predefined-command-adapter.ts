import { type SendZigbeeCommandForPredefinedProperties } from '../../../../../../../../../../../command/subsets/for-predefined-properties/entities/actions/send/send-zigbee-command-for-predefined-properties.js';
import { type ZigbeeCommandObserverForPredefinedProperties } from '../../../../../../../../../../../command/subsets/for-predefined-properties/entities/events/observer/zigbee-command-observer-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../../../../../../command/subsets/for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type ZigbeeReadAttributesCommandPredefinedProperties } from '../../../../../../../../../../commands/0x00--read-attributes/zigbee-read-attributes-command.js';
import { createReadZigbeeAttributesAdapterUsingZigbeePredefinedCommandAdapter } from '../../../implementations/using-zigbee-predefined-command-adapter/create-read-zigbee-attributes-adapter-using-zigbee-predefined-command-adapter.js';
import { type ReadZigbeeAttributesAdapter } from '../../../read-zigbee-attributes-adapter.js';
import { type ZigbeeReadAttributesCommandPredefinedPropertiesWithCluster } from '../../zigbee-read-attributes-command-predefined-properties-with-cluster.js';
import { type ZigbeeReadAttributesResponseCommandPredefinedPropertiesWithCluster } from '../../zigbee-read-attributes-response-command-predefined-properties-with-cluster.js';

export interface CreateReadZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptions {
  readonly send: SendZigbeeCommandForPredefinedProperties<ZigbeeReadAttributesCommandPredefinedPropertiesWithCluster>;
  readonly observer: ZigbeeCommandObserverForPredefinedProperties<ZigbeeReadAttributesResponseCommandPredefinedPropertiesWithCluster>;
  readonly cluster: number;
}

export function createReadZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapter({
  send,
  observer,
  cluster,
}: CreateReadZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptions): ReadZigbeeAttributesAdapter {
  return createReadZigbeeAttributesAdapterUsingZigbeePredefinedCommandAdapter({
    send: (
      command: ZigbeeCommandForPredefinedProperties<ZigbeeReadAttributesCommandPredefinedProperties>,
    ): Promise<void> => {
      return send({
        ...command,
        cluster,
      });
    },
    observer: observer.filter(
      (
        command: ZigbeeCommandForPredefinedProperties<ZigbeeReadAttributesResponseCommandPredefinedPropertiesWithCluster>,
      ): boolean => {
        return command.cluster === cluster;
      },
    ),
  });
}

/*---*/

export type CreateReadZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptionsForConsumer =
  Omit<
    CreateReadZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptions,
    'cluster'
  >;
