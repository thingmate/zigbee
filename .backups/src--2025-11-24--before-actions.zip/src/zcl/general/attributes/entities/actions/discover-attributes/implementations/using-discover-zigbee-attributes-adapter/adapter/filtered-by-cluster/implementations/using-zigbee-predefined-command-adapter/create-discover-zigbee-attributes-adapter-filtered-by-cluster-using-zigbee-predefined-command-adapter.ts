import { type SendZigbeeCommandForPredefinedProperties } from '../../../../../../../../../../../command/subsets/for-predefined-properties/entities/actions/send/send-zigbee-command-for-predefined-properties.js';
import { type ZigbeeCommandObserverForPredefinedProperties } from '../../../../../../../../../../../command/subsets/for-predefined-properties/entities/events/observer/zigbee-command-observer-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../../../../../../command/subsets/for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type ZigbeeDiscoverAttributesCommandPredefinedProperties } from '../../../../../../../../../../commands/0x0c--discover-attributes/zigbee-discover-attributes-command.js';
import { type DiscoverZigbeeAttributesAdapter } from '../../../discover-zigbee-attributes-adapter.js';
import { createDiscoverZigbeeAttributesAdapterUsingZigbeePredefinedCommandAdapter } from '../../../implementations/using-zigbee-predefined-command-adapter/create-discover-zigbee-attributes-adapter-using-zigbee-predefined-command-adapter.js';
import { type ZigbeeDiscoverAttributesCommandPredefinedPropertiesWithCluster } from '../../zigbee-discover-attributes-command-predefined-properties-with-cluster.js';
import { type ZigbeeDiscoverAttributesResponseCommandPredefinedPropertiesWithCluster } from '../../zigbee-discover-attributes-response-command-predefined-properties-with-cluster.js';

export interface CreateDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptions {
  readonly send: SendZigbeeCommandForPredefinedProperties<ZigbeeDiscoverAttributesCommandPredefinedPropertiesWithCluster>;
  readonly observer: ZigbeeCommandObserverForPredefinedProperties<ZigbeeDiscoverAttributesResponseCommandPredefinedPropertiesWithCluster>;
  readonly cluster: number;
}

export function createDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapter({
  send,
  observer,
  cluster,
}: CreateDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptions): DiscoverZigbeeAttributesAdapter {
  return createDiscoverZigbeeAttributesAdapterUsingZigbeePredefinedCommandAdapter({
    send: (
      command: ZigbeeCommandForPredefinedProperties<ZigbeeDiscoverAttributesCommandPredefinedProperties>,
    ): Promise<void> => {
      return send({
        ...command,
        cluster,
      });
    },
    observer: observer.filter(
      (
        command: ZigbeeCommandForPredefinedProperties<ZigbeeDiscoverAttributesResponseCommandPredefinedPropertiesWithCluster>,
      ): boolean => {
        return command.cluster === cluster;
      },
    ),
  });
}

/*---*/

export type CreateDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptionsForConsumer =
  Omit<
    CreateDiscoverZigbeeAttributesAdapterFilteredByClusterUsingZigbeePredefinedCommandAdapterOptions,
    'cluster'
  >;
