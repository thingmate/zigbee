import { type EntityAction } from '@thingmate/entity';

export type ReadZigbeeAttribute<GValue> = EntityAction<[], GValue>;
