import { type EntityEvent } from '@thingmate/entity';
import { type ZigbeeCommandForExcludedPredefinedProperties } from '../../../zigbee-command-for-excluded-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../zigbee-command-for-predefined-properties-constraint.js';

/**
 * Represents a ZigbeeCommandObserver emitting a partial ZigbeeCommand without some predefined properties.
 */
export type ZigbeeCommandObserverForExcludedPredefinedProperties<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
> = EntityEvent<ZigbeeCommandForExcludedPredefinedProperties<GPredefinedProperties>>;
