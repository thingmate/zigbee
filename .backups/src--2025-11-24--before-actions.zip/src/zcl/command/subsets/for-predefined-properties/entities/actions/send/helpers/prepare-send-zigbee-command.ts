import { type Abortable } from '@xstd/abortable';
import { type SendZigbeeCommand } from '../../../../../../entities/actions/send/send-zigbee-command.js';
import { type ZigbeeCommand } from '../../../../../../zigbee-command.js';
import { type ZigbeeCommandForExcludedPredefinedProperties } from '../../../../zigbee-command-for-excluded-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../zigbee-command-for-predefined-properties-constraint.js';
import { type SendZigbeeCommandForExcludedPredefinedProperties } from '../send-zigbee-command-for-excluded-predefined-properties.js';

export function prepareSendZigbeeCommand<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
>(
  send: SendZigbeeCommand,
  predefinedZigbeeCommand: GPredefinedProperties,
): SendZigbeeCommandForExcludedPredefinedProperties<GPredefinedProperties> {
  return (
    command: ZigbeeCommandForExcludedPredefinedProperties<GPredefinedProperties>,
    options?: Abortable,
  ): Promise<void> => {
    return send(
      {
        ...command,
        ...predefinedZigbeeCommand,
      } as unknown as ZigbeeCommand,
      options,
    );
  };
}
