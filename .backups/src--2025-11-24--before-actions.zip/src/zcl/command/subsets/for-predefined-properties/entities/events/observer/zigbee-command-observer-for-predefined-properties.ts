import { type EntityEvent } from '@thingmate/entity';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../zigbee-command-for-predefined-properties.js';

/**
 * Represents a ZigbeeCommandObserver emitting the minimal partial ZigbeeCommand to match some predefined properties.
 */
export type ZigbeeCommandObserverForPredefinedProperties<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
> = EntityEvent<ZigbeeCommandForPredefinedProperties<GPredefinedProperties>>;
