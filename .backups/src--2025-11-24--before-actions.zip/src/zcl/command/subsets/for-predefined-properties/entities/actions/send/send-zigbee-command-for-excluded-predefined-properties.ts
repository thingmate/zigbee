import { type EntityAction } from '@thingmate/entity';
import { type ZigbeeCommandForExcludedPredefinedProperties } from '../../../zigbee-command-for-excluded-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../zigbee-command-for-predefined-properties-constraint.js';

/**
 * Represents a SendZigbeeCommand function sending a partial ZigbeeCommand without some predefined properties.
 */
export type SendZigbeeCommandForExcludedPredefinedProperties<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
> = EntityAction<
  [command: ZigbeeCommandForExcludedPredefinedProperties<GPredefinedProperties>],
  void
>;
