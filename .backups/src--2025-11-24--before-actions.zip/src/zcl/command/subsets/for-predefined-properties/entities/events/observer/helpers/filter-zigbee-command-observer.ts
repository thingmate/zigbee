import { NONE, type None } from '@xstd/none';
import { type ZigbeeCommandObserver } from '../../../../../../entities/events/observer/zigbee-command-observer.js';
import { type ZigbeeCommand } from '../../../../../../zigbee-command.js';
import { type ZigbeeCommandForExcludedPredefinedProperties } from '../../../../zigbee-command-for-excluded-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandObserverForExcludedPredefinedProperties } from '../zigbee-command-observer-for-excluded-predefined-properties.js';

export function filterZigbeeCommandObserver<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
>(
  observer: ZigbeeCommandObserver,
  partialZigbeeCommand: GPredefinedProperties,
): ZigbeeCommandObserverForExcludedPredefinedProperties<GPredefinedProperties> {
  const entries: readonly (readonly [key: string, value: unknown])[] =
    Object.entries(partialZigbeeCommand);

  return observer.mapFilter(
    (
      input: ZigbeeCommand,
    ): ZigbeeCommandForExcludedPredefinedProperties<GPredefinedProperties> | None => {
      const output: ZigbeeCommand = Object.assign({}, input);

      for (const [key, value] of entries) {
        if (value === Reflect.get(input, key)) {
          Reflect.deleteProperty(output, key);
        } else {
          return NONE;
        }
      }

      return output as ZigbeeCommandForExcludedPredefinedProperties<GPredefinedProperties>;
    },
  );
}
