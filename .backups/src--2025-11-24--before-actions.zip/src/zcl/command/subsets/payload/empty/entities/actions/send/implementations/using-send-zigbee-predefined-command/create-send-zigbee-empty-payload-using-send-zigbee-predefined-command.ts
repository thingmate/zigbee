import { type Abortable } from '@xstd/abortable';
import { type SendZigbeeCommandForPredefinedProperties } from '../../../../../../../for-predefined-properties/entities/actions/send/send-zigbee-command-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type SendZigbeeEmptyPayload } from '../../send-zigbee-empty-payload.js';

export interface CreateSendZigbeeEmptyPayloadUsingSendZigbeePredefinedCommandOptions<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
> {
  readonly send: SendZigbeeCommandForPredefinedProperties<GPredefinedProperties>;
  readonly commandPredefinedProperties: GPredefinedProperties;
}

export function createSendZigbeeEmptyPayloadUsingSendZigbeePredefinedCommand<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
>({
  send,
  commandPredefinedProperties,
}: CreateSendZigbeeEmptyPayloadUsingSendZigbeePredefinedCommandOptions<GPredefinedProperties>): SendZigbeeEmptyPayload {
  return (options?: Abortable): Promise<void> => {
    return send(
      {
        ...commandPredefinedProperties,
        payload: EMPTY_PAYLOAD,
      } as ZigbeeCommandForPredefinedProperties<GPredefinedProperties>,
      options,
    );
  };
}

const EMPTY_PAYLOAD: Uint8Array = new Uint8Array(0);
