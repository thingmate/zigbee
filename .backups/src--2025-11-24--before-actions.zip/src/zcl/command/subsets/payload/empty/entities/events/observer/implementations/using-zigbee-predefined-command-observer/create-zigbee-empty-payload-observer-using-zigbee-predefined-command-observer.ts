import { NONE, type None } from '@xstd/none';
import { type ZigbeeCommandObserverForPredefinedProperties } from '../../../../../../../for-predefined-properties/entities/events/observer/zigbee-command-observer-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type ZigbeeEmptyPayloadObserver } from '../../zigbee-empty-payload-observer.js';

export interface CreateZigbeePayloadObserverUsingZigbeePredefinedCommandObserverOptions<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
> {
  readonly observer: ZigbeeCommandObserverForPredefinedProperties<GPredefinedProperties>;
  readonly commandPredefinedProperties: GPredefinedProperties;
}

export function createZigbeeEmptyPayloadObserverUsingZigbeePredefinedCommandObserver<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
>({
  observer,
  commandPredefinedProperties,
}: CreateZigbeePayloadObserverUsingZigbeePredefinedCommandObserverOptions<GPredefinedProperties>): ZigbeeEmptyPayloadObserver {
  const entries: readonly (readonly [key: string, value: unknown])[] = Object.entries(
    commandPredefinedProperties,
  );

  return observer.mapFilter(
    (command: ZigbeeCommandForPredefinedProperties<GPredefinedProperties>): void | None => {
      return entries.every(([key, value]: readonly [string, unknown]): boolean => {
        return value === Reflect.get(command, key);
      })
        ? undefined
        : NONE;
    },
  );
}
