import { type Abortable } from '@xstd/abortable';
import { type EncodeFunction, Encoder } from '@xstd/codec';
import { type SendZigbeeCommandForPredefinedProperties } from '../../../../../../../for-predefined-properties/entities/actions/send/send-zigbee-command-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type SendZigbeeDecodedPayload } from '../../send-zigbee-decoded-payload.js';

export interface CreateSendZigbeeDecodedPayloadUsingSendZigbeePredefinedCommandOptions<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
  GPayload,
> {
  readonly send: SendZigbeeCommandForPredefinedProperties<GPredefinedProperties>;
  readonly commandPredefinedProperties: GPredefinedProperties;
  readonly encode: EncodeFunction<GPayload>;
}

export function createSendZigbeeDecodedPayloadUsingSendZigbeePredefinedCommand<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
  GPayload,
>({
  send,
  commandPredefinedProperties,
  encode,
}: CreateSendZigbeeDecodedPayloadUsingSendZigbeePredefinedCommandOptions<
  GPredefinedProperties,
  GPayload
>): SendZigbeeDecodedPayload<GPayload> {
  return (payload: GPayload, options?: Abortable): Promise<void> => {
    return send(
      {
        ...commandPredefinedProperties,
        payload: Encoder.encode(payload, encode),
      } as ZigbeeCommandForPredefinedProperties<GPredefinedProperties>,
      options,
    );
  };
}
