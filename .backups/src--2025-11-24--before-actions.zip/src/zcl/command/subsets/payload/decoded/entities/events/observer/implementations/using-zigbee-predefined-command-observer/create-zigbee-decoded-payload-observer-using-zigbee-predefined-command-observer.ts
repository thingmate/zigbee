import { type DecodeFunction, Decoder } from '@xstd/codec';
import { type None, NONE } from '@xstd/none';
import { type ZigbeeCommandObserverForPredefinedProperties } from '../../../../../../../for-predefined-properties/entities/events/observer/zigbee-command-observer-for-predefined-properties.js';
import { type ZigbeeCommandForPredefinedPropertiesConstraint } from '../../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties-constraint.js';
import { type ZigbeeCommandForPredefinedProperties } from '../../../../../../../for-predefined-properties/zigbee-command-for-predefined-properties.js';
import { type ZigbeeDecodedPayloadObserver } from '../../zigbee-decoded-payload-observer.js';

export interface CreateZigbeeDecodedPayloadObserverUsingZigbeePredefinedCommandObserverOptions<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
  GPayload,
> {
  readonly observer: ZigbeeCommandObserverForPredefinedProperties<GPredefinedProperties>;
  readonly commandPredefinedProperties: GPredefinedProperties;
  readonly decode: DecodeFunction<GPayload>;
}

export function createZigbeeDecodedPayloadObserverUsingZigbeePredefinedCommandObserver<
  GPredefinedProperties extends ZigbeeCommandForPredefinedPropertiesConstraint,
  GPayload,
>({
  observer,
  commandPredefinedProperties,
  decode,
}: CreateZigbeeDecodedPayloadObserverUsingZigbeePredefinedCommandObserverOptions<
  GPredefinedProperties,
  GPayload
>): ZigbeeDecodedPayloadObserver<GPayload> {
  const entries: readonly (readonly [key: string, value: unknown])[] = Object.entries(
    commandPredefinedProperties,
  );

  return observer.mapFilter(
    (command: ZigbeeCommandForPredefinedProperties<GPredefinedProperties>): GPayload | None => {
      return entries.every(([key, value]: readonly [string, unknown]): boolean => {
        return value === Reflect.get(command, key);
      })
        ? Decoder.decode(command.payload, decode)
        : NONE;
    },
  );
}
