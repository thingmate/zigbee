import { type ZigbeeEmptyPayloadObserver } from '../../../../../../../../command/subsets/payload/empty/entities/events/observer/zigbee-empty-payload-observer.js';

export type ZigbeeOffCommandObserver = ZigbeeEmptyPayloadObserver;
