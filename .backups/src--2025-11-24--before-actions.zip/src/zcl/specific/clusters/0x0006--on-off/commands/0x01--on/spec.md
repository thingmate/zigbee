3.8.2.3.2 On Command
