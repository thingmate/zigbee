import { type ZigbeeAttributesObserver } from '../../../../../../../general/attributes/entities/events/attributes-observer/zigbee-attributes-observer.js';

export type ZigbeeOnOffAttributesObserver = ZigbeeAttributesObserver;
