import { type ZigbeeAttributeObserver } from '../../../../../../../../general/attributes/entities/events/attribute-observer/zigbee-attribute-observer.js';

export type ZigbeeOnOffAttributeObserver = ZigbeeAttributeObserver<boolean>;
