export const ZIGBEE_CLUSTER_0x0006 = 0x0006;

export type ZigbeeCluster0x0006 = typeof ZIGBEE_CLUSTER_0x0006;
