3.2.2.2.5 ManufacturerName Attribute
