import { type ReadZigbeeAttributes } from '../../../../../../../general/attributes/entities/actions/read-attributes/read-zigbee-attributes.js';

export type ReadZigbeeBasicAttributes = ReadZigbeeAttributes;
