2.6.2 Data Types
p85
