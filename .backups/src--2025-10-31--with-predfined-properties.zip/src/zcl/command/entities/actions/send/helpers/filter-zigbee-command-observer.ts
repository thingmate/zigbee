import type { EntityAction } from '@thingmate/entity';
import { type ZigbeeCommand } from '../../../../zigbee-command.js';
import { SendZigbeeCommand } from '../send-zigbee-command.js';
import { type ZigbeeCommandObserver } from '../zigbee-command-observer.js';

export function filterZigbeeCommandObserver(
  observer: ZigbeeCommandObserver,
  predefinedZigbeeCommand: Partial<ZigbeeCommand>,
): ZigbeeCommandObserver {
  const entries: readonly (readonly [key: string, value: unknown])[] =
    Object.entries(predefinedZigbeeCommand);

  return observer.filter((input: ZigbeeCommand): boolean => {
    return entries.every(([key, value]: readonly [string, unknown]): boolean => {
      return value === Reflect.get(input, key);
    });
  });
}

export type PreparedSendZigbeeCommand<Gprede> = EntityAction<[command: ZigbeeCommand], void>;

export function prepareSendZigbeeCommand(
  send: SendZigbeeCommand,
  predefinedZigbeeCommand: Partial<ZigbeeCommand>,
): SendZigbeeCommand {}
