import { type FilterFunction } from '@xstd/functional';
import { type ZigbeeCommand } from '../../../../zigbee-command.js';

export function createZigbeeCommandObserverFilter(
  partialZigbeeCommand: Partial<ZigbeeCommand>,
): FilterFunction<ZigbeeCommand> {
  const entries: readonly (readonly [key: string, value: unknown])[] =
    Object.entries(partialZigbeeCommand);

  return (input: ZigbeeCommand): boolean => {
    return entries.every(([key, value]: readonly [string, unknown]): boolean => {
      return value === Reflect.get(input, key);
    });
  };
}
