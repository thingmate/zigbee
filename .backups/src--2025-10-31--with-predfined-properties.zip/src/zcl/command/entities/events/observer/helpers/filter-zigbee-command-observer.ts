import { type ZigbeeCommand } from '../../../../zigbee-command.js';
import { type ZigbeeCommandObserver } from '../zigbee-command-observer.js';
import { createZigbeeCommandObserverFilter } from './create-zigbee-command-observer-filter.js';

export function filterZigbeeCommandObserver(
  observer: ZigbeeCommandObserver,
  partialZigbeeCommand: Partial<ZigbeeCommand>,
): ZigbeeCommandObserver {
  return observer.filter(createZigbeeCommandObserverFilter(partialZigbeeCommand));
}
