import { type ZigbeeCommand } from '../../zigbee-command.js';

export type ZigbeePrefilteredCommandPrefilteredPropertiesConstraint = Partial<
  Omit<ZigbeeCommand, 'payload'>
>;

/**
 * Represents a ZigbeeCommand with prefiltered properties.
 */
export type ZigbeePrefilteredCommand<
  GPrefilteredProperties extends ZigbeePrefilteredCommandPrefilteredPropertiesConstraint,
> = Pick<ZigbeeCommand, Extract<keyof GPrefilteredProperties, keyof ZigbeeCommand> | 'payload'>;
