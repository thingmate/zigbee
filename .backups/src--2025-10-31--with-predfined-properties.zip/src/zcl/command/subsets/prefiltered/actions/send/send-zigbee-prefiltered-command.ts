import { type EntityAction } from '@thingmate/entity';
import {
  type ZigbeePrefilteredCommand,
  type ZigbeePrefilteredCommandPrefilteredPropertiesConstraint,
} from '../../../zigbee-prefiltered-command.js';

export type SendZigbeePrefilteredCommand<
  GPrefilteredProperties extends ZigbeePrefilteredCommandPrefilteredPropertiesConstraint,
> = EntityAction<[command: ZigbeePrefilteredCommand<GPrefilteredProperties>], void>;
