import { type DecodeFunction, Decoder } from '@xstd/codec';
import { createZigbeeCommandObserverFilter } from '../../../../../../../../entities/events/observer/helpers/create-zigbee-command-observer-filter.js';
import { type ZigbeePredefinedCommandObserver } from '../../../../../../../predefined/entities/events/observer/zigbee-predefined-command-observer.js';
import {
  type ZigbeePredefinedCommand,
  type ZigbeePredefinedCommandPredefinedPropertiesConstraint,
} from '../../../../../../../predefined/zigbee-predefined-command.js';
import { type ZigbeeDecodedPayloadObserver } from '../../zigbee-decoded-payload-observer.js';

export interface CreateZigbeeDecodedPayloadObserverUsingZigbeePredefinedCommandObserverOptions<
  GPredefinedProperties extends ZigbeePredefinedCommandPredefinedPropertiesConstraint,
  GPayload,
> {
  readonly observer: ZigbeePredefinedCommandObserver<GPredefinedProperties>;
  readonly commandPredefinedProperties: GPredefinedProperties;
  readonly decode: DecodeFunction<GPayload>;
}

export function createZigbeeDecodedPayloadObserverUsingZigbeePredefinedCommandObserver<
  GPredefinedProperties extends ZigbeePredefinedCommandPredefinedPropertiesConstraint,
  GPayload,
>({
  observer,
  commandPredefinedProperties,
  decode,
}: CreateZigbeeDecodedPayloadObserverUsingZigbeePredefinedCommandObserverOptions<
  GPredefinedProperties,
  GPayload
>): ZigbeeDecodedPayloadObserver<GPayload> {
  return observer
    .filter(createZigbeeCommandObserverFilter(commandPredefinedProperties))
    .map(({ payload }: ZigbeePredefinedCommand<GPredefinedProperties>): GPayload => {
      return Decoder.decode(payload, decode);
    });
}
