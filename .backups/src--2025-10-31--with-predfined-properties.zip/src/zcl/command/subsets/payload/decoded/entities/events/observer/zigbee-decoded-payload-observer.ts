import { type EntityEvent } from '@thingmate/entity';

export type ZigbeeDecodedPayloadObserver<GPayload> = EntityEvent<GPayload>;
