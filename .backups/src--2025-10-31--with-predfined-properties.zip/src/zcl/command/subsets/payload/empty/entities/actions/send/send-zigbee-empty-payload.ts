import { type EntityAction } from '@thingmate/entity';

export type SendZigbeeEmptyPayload = EntityAction<[], void>;
