import { type EntityEvent } from '@thingmate/entity';

export type ZigbeeEmptyPayloadObserver = EntityEvent<void>;
