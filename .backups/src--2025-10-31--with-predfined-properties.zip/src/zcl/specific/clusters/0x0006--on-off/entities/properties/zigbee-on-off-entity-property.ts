import { type EntityProperty } from '@thingmate/entity';

export type ZigbeeOnOffEntityProperty = EntityProperty<boolean>;
