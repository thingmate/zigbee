import { type SendZigbeeEmptyPayload } from '../../../../../../../../command/subsets/payload/empty/entities/actions/send/send-zigbee-empty-payload.js';

export type SendZigbeeOffCommand = SendZigbeeEmptyPayload;
