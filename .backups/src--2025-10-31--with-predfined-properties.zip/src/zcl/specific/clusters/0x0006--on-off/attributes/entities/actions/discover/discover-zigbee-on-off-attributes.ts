import { type DiscoverZigbeeAttributes } from '../../../../../../../general/attributes/entities/actions/discover-attributes/discover-zigbee-attributes.js';

export type DiscoverZigbeeOnOffAttributes = DiscoverZigbeeAttributes;
