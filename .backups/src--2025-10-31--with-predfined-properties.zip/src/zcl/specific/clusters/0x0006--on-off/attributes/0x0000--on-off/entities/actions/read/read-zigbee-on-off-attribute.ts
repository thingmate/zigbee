import { type ReadZigbeeAttribute } from '../../../../../../../../general/attributes/entities/actions/read-attribute/read-zigbee-attribute.js';

export type ReadZigbeeOnOffAttribute = ReadZigbeeAttribute<boolean>;
