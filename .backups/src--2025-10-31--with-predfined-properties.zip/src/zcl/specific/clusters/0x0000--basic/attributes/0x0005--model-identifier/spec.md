3.2.2.2.6 ModelIdentifier Attribute
