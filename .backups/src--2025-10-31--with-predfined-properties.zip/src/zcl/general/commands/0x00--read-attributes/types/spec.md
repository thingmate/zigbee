2.5.1.1 Read Attributes Command Frame Format
