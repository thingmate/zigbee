2.5.1 Read Attributes Command
