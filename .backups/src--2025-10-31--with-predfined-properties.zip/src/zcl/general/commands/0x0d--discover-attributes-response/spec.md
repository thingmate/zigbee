2.5.14 Discover Attributes Response Command
