Figure 2-24. Format of the Attribute Report Fields
